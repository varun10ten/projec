import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, classification_report, mean_squared_error, r2_score
import xgboost as xgb
import lightgbm as lgb
from datetime import timedelta
from imblearn.over_sampling import SMOTE
import warnings
import os
import gc

# Suppress warnings
warnings.filterwarnings('ignore', category=UserWarning, module='xgboost')
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=pd.errors.SettingWithCopyWarning)

# Set a consistent style for plots
plt.style.use('seaborn-v0_8-whitegrid')

def load_and_preprocess_data(file_path):
    """
    Loads data and performs all preprocessing, cleaning, and feature engineering.
    """
    try:
        print("Loading and preprocessing data...")
        df = pd.read_csv(file_path)

        # Drop rows where the target variable is missing early
        df.dropna(subset=['is_defaulted'], inplace=True)

        # Convert date columns
        df['date_opened'] = pd.to_datetime(df['date_opened'], errors='coerce')
        df['date_closed'] = pd.to_datetime(df['date_closed'], errors='coerce')
        df['date_of_birth'] = pd.to_datetime(df['date_of_birth'], errors='coerce')
        today = pd.to_datetime('today')

        # Feature Engineering: Combine steps for efficiency
        df['date_last_activity'] = df['date_closed'].fillna(df['date_opened'])
        df['time_since_last_activity_months'] = (today - df['date_last_activity']).dt.days / 30.44

        df['utilization_ratio'] = df['current_balance'] / (df['credit_limit'] + 1e-6)
        df['on_time_payment_rate'] = 1 - (df['payment_history_status'] != 'On Time').astype(int)

        # Groupby operations for efficiency
        grouped = df.groupby('customer_id')
        df['avg_credit_utilization'] = grouped['utilization_ratio'].transform('mean')
        df['max_credit_utilization'] = grouped['utilization_ratio'].transform('max')

        df['num_delinquencies_30'] = grouped['payment_history_status'].transform(lambda x: (x == '30-60 Days Late').sum())
        df['num_delinquencies_60'] = grouped['payment_history_status'].transform(lambda x: (x == '60-90 Days Late').sum())
        df['num_delinquencies_90+'] = grouped['payment_history_status'].transform(lambda x: (x.str.contains('Defaulted')).sum())

        df['delinquency_score'] = df['num_delinquencies_30'] * 0.5 + df['num_delinquencies_60'] * 1.5 + df['num_delinquencies_90+'] * 3.0
        
        df['credit_to_income_ratio'] = df['credit_limit'] / (df['annual_income'] + 1e-6)
        df['age_years'] = (today - df['date_of_birth']).dt.days / 365.25
        df['length_of_credit_history_years'] = (today - grouped['date_opened'].transform('min')).dt.days / 365.25
        
        df['total_monthly_debt'] = grouped['current_balance'].transform('sum')
        df['DTI'] = df['total_monthly_debt'] * 12 / (df['annual_income'] + 1e-6)
        df['account_diversity_score'] = grouped['account_type'].transform('nunique')

        # Create synthetic credit score for regression task
        prob_default = 1 / (1 + np.exp(
            0.5 * df['on_time_payment_rate'] + 0.1 * np.log(df['length_of_credit_history_years'] + 1) - 
            0.05 * np.log(df['DTI'] + 1) + 0.1 * df['age_years'] + 
            0.000001 * df['annual_income']
        ))
        df['credit_score'] = 300 + (550) * (1 - np.clip(prob_default, 0, 1))

        # Handle missing values after feature engineering
        numerical_cols = ['credit_limit', 'current_balance', 'annual_income', 'total_payments_made', 'bureau_score_at_opening', 'months_since_last_delinquency']
        for col in numerical_cols:
            df[col].fillna(df[col].mean(), inplace=True)

        categorical_cols = ['employment_status', 'marital_status', 'education_level', 'account_type', 'payment_history_status']
        for col in categorical_cols:
            df[col].fillna(df[col].mode()[0], inplace=True)
            
        # Handle outliers using capping
        outlier_cols = ['annual_income', 'credit_limit', 'total_monthly_debt', 'DTI', 'credit_to_income_ratio']
        for col in outlier_cols:
            q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            df[col] = df[col].clip(lower_bound, upper_bound)
        
        # Encoding
        nominal_cols = ['employment_status', 'marital_status', 'account_type']
        df = pd.get_dummies(df, columns=nominal_cols, drop_first=True, dtype=int)
        
        education_level_mapping = {'High School': 0, 'Bachelor\'s': 1, 'Master\'s': 2, 'PhD': 3}
        df['education_level'] = df['education_level'].map(education_level_mapping)
        df['education_level'].fillna(-1, inplace=True)

        # Drop unnecessary columns
        df.drop(columns=[
            'account_id', 'customer_id', 'date_opened', 'date_closed', 'date_of_birth',
            'current_address', 'payment_history_status', 'date_last_activity', 
            'utilization_ratio', 'is_defaulted'
        ], inplace=True, errors='ignore')

        df.dropna(inplace=True)
        gc.collect() # Garbage collection to free up memory
        
        print("Data preprocessed and ready for modeling.")
        return df

    except FileNotFoundError as e:
        print(f"Error: The file was not found. Details: {e}")
        return pd.DataFrame()

def train_and_evaluate_models(X_train, X_val, y_class_train, y_class_val, y_reg_train, y_reg_val):
    """
    Trains and evaluates models for both classification and regression.
    """
    print("\n--- Training and Evaluating Models ---")

    # --- Classification Problem (Credit Default) ---
    print("\n--- Training Random Forest Classifier with SMOTE ---")
    smote = SMOTE(random_state=42, n_jobs=-1)
    X_train_res, y_class_train_res = smote.fit_resample(X_train, y_class_train)

    # Use a simplified, yet effective RandomizedSearch
    rf_classifier = RandomForestClassifier(random_state=42, n_jobs=-1)
    rf_params = {
        'n_estimators': [100, 200], 'max_depth': [10, 20],
        'min_samples_split': [2, 5]
    }
    random_search_clf = RandomizedSearchCV(rf_classifier, rf_params, n_iter=10, cv=3, random_state=42, n_jobs=-1, scoring='f1_weighted')
    random_search_clf.fit(X_train_res, y_class_train_res)
    best_classifier = random_search_clf.best_estimator_
    print(f"Best classifier: {best_classifier.__class__.__name__} with F1-Score: {random_search_clf.best_score_:.4f}")

    # --- Regression Problem (Credit Score) ---
    print("\n--- Training LightGBM Regressor ---")
    lgbm_regressor = lgb.LGBMRegressor(random_state=42, n_jobs=-1)
    lgbm_params = {
        'n_estimators': [100, 200, 300], 'learning_rate': [0.05, 0.1],
        'num_leaves': [31, 50]
    }
    random_search_reg = RandomizedSearchCV(lgbm_regressor, lgbm_params, n_iter=10, cv=3, random_state=42, n_jobs=-1, scoring='r2')
    random_search_reg.fit(X_train, y_reg_train)
    best_regressor = random_search_reg.best_estimator_
    print(f"Best regressor: {best_regressor.__class__.__name__} with R-squared: {random_search_reg.best_score_:.4f}")

    return best_classifier, best_regressor

def final_evaluation(X_test, y_class_test, y_reg_test, best_classifier, best_regressor):
    """
    Performs the final evaluation on the test set.
    """
    print("\n--- Final Evaluation on the Test Set ---")

    # Classification
    print(f"\n--- Final Evaluation of {best_classifier.__class__.__name__} ---")
    y_pred_class = best_classifier.predict(X_test)
    print(f"Final Classification Report:\n{classification_report(y_class_test, y_pred_class)}")
    ConfusionMatrixDisplay.from_estimator(best_classifier, X_test, y_class_test, display_labels=['No Default', 'Default'], cmap=plt.cm.Blues, values_format='d')
    plt.title(f'Final Confusion Matrix for {best_classifier.__class__.__name__} (Test Set)')
    plt.show()

    # Regression
    print(f"\n--- Final Evaluation of {best_regressor.__class__.__name__} ---")
    y_pred_reg = best_regressor.predict(X_test)
    mse = mean_squared_error(y_reg_test, y_pred_reg)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_reg_test, y_pred_reg)
    print(f"Final Evaluation for {best_regressor.__class__.__name__} (Test Set):")
    print(f"  - Mean Squared Error (MSE): {mse:.4f}")
    print(f"  - Root Mean Squared Error (RMSE): {rmse:.4f}")
    print(f"  - R-squared (R²): {r2:.4f}")
    
    # Feature Importance Plot for Regression
    if hasattr(best_regressor, 'feature_importances_'):
        print("\n--- Feature Importance for Credit Score Prediction ---")
        importances = best_regressor.feature_importances_
        feature_names = X_test.columns
        sorted_indices = np.argsort(importances)[::-1]
        
        plt.figure(figsize=(12, 8))
        plt.title(f"Feature Importance - {best_regressor.__class__.__name__} (Credit Score)")
        sns.barplot(x=importances[sorted_indices][:15], y=feature_names[sorted_indices][:15])
        plt.xlabel('Feature Importance')
        plt.ylabel('Feature')
        plt.tight_layout()
        plt.show()

def main():
    """
    Main function to run the optimized pipeline.
    """
    file_path = r"C:\Users\varun\Downloads\merged_credit_data transunion.csv"
    
    # Preprocess all data at once
    df = load_and_preprocess_data(file_path)
    if df.empty:
        return

    # Define features and targets
    X = df.drop(columns=['credit_score'])
    y_reg = df['credit_score']
    y_class = df['is_defaulted'] = df['on_time_payment_rate'].apply(lambda x: 1 if x < 1 else 0) # Simplified logic for is_defaulted
    
    # Split data
    X_train_val, X_test, y_class_train_val, y_class_test = train_test_split(
        X, y_class, test_size=0.2, random_state=42, stratify=y_class
    )
    y_reg_train_val = y_reg.loc[X_train_val.index]
    y_reg_test = y_reg.loc[X_test.index]

    X_train, X_val, y_class_train, y_class_val = train_test_split(
        X_train_val, y_class_train_val, test_size=0.25, random_state=42, stratify=y_class_train_val
    )
    y_reg_train = y_reg_train_val.loc[X_train.index]
    y_reg_val = y_reg_train_val.loc[X_val.index]

    # Train and evaluate models
    best_classifier, best_regressor = train_and_evaluate_models(
        X_train, X_val, y_class_train, y_class_val, y_reg_train, y_reg_val
    )

    # Final evaluation on the test set
    final_evaluation(X_test, y_class_test, y_reg_test, best_classifier, best_regressor)

if __name__ == "__main__":
    main()