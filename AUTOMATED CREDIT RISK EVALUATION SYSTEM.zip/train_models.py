import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, classification_report, mean_squared_error, r2_score
import xgboost as xgb
from imblearn.over_sampling import SMOTE
import warnings
import gc
from datetime import timedelta
import os
import pickle
# LIME IMPORT
from lime.lime_tabular import LimeTabularExplainer 

# Suppress all relevant warnings
warnings.filterwarnings('ignore', category=UserWarning, module='xgboost')
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=pd.errors.SettingWithCopyWarning)
warnings.filterwarnings('ignore', category=UserWarning, module='seaborn')

# Set a consistent style for plots
plt.style.use('seaborn-v0_8-whitegrid')

# ====================================================================
# 1. DATA LOADING AND PREPROCESSING (Unchanged)
# ====================================================================

def load_and_preprocess_data(file_path):
    """Loads data and performs all preprocessing, cleaning, and feature engineering."""
    try:
        print("Loading and preprocessing data...")
        df = pd.read_csv(file_path)

        df.dropna(subset=['is_defaulted'], inplace=True)

        # Convert date columns
        df['date_opened'] = pd.to_datetime(df['date_opened'], errors='coerce')
        df['date_closed'] = pd.to_datetime(df['date_closed'], errors='coerce')
        df['date_of_birth'] = pd.to_datetime(df['date_of_birth'], errors='coerce')
        today = pd.to_datetime('today')

        # Feature Engineering Setup
        df['date_last_activity'] = df['date_closed'].fillna(df['date_opened'])
        df['time_since_last_activity_months'] = (today - df['date_last_activity']).dt.days / 30.44

        df['utilization_ratio'] = df['current_balance'] / (df['credit_limit'] + 1e-6)
        df['payment_was_late'] = (df['payment_history_status'] != 'On Time').astype(int) 
        df.rename(columns={'is_defaulted': 'y_class_original'}, inplace=True)

        # Groupby operations
        grouped = df.groupby('customer_id')
        df['avg_credit_utilization'] = grouped['utilization_ratio'].transform('mean')
        df['max_credit_utilization'] = grouped['utilization_ratio'].transform('max')

        df['num_delinquencies_30'] = grouped['payment_history_status'].transform(lambda x: (x == '30-60 Days Late').sum())
        df['num_delinquencies_60'] = grouped['payment_history_status'].transform(lambda x: (x == '60-90 Days Late').sum())
        df['num_delinquencies_90+'] = grouped['payment_history_status'].transform(lambda x: (x.str.contains('Defaulted')).sum())

        df['delinquency_score'] = df['num_delinquencies_30'] * 0.5 + df['num_delinquencies_60'] * 1.5 + df['num_delinquencies_90+'] * 3.0
         
        df['credit_to_income_ratio'] = df['credit_limit'] / (df['annual_income'] + 1e-6)
        df['age_years'] = (today - df['date_of_birth']).dt.days / 365.25
        df['length_of_credit_history_years'] = (today - grouped['date_opened'].transform('min')).dt.days / 365.25
         
        df['total_monthly_debt'] = grouped['current_balance'].transform('sum')
        df['DTI'] = df['total_monthly_debt'] * 12 / (df['annual_income'] + 1e-6)
        df['account_diversity_score'] = grouped['account_type'].transform('nunique')

        # Create synthetic credit score
        prob_default = 1 / (1 + np.exp(
            0.5 * (1 - df['payment_was_late']) + 0.1 * np.log(df['length_of_credit_history_years'] + 1) - 
            0.05 * np.log(df['DTI'] + 1) + 0.1 * df['age_years'] + 
            0.000001 * df['annual_income']
        ))
        df['credit_score'] = 300 + (550) * (1 - np.clip(prob_default, 0, 1))

        # Handle missing values
        numerical_cols = ['credit_limit', 'current_balance', 'annual_income', 'total_payments_made', 'bureau_score_at_opening', 'months_since_last_delinquency']
        for col in numerical_cols:
            df[col].fillna(df[col].mean(), inplace=True)

        categorical_cols = ['employment_status', 'marital_status', 'education_level', 'account_type', 'payment_history_status']
        for col in categorical_cols:
            df[col].fillna(df[col].mode()[0], inplace=True)
             
        # Handle outliers using capping
        outlier_cols = ['annual_income', 'credit_limit', 'total_monthly_debt', 'DTI', 'credit_to_income_ratio']
        for col in outlier_cols:
            q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            df[col] = df[col].clip(lower_bound, upper_bound)
         
        # Encoding
        nominal_cols = ['employment_status', 'marital_status', 'account_type']
        df = pd.get_dummies(df, columns=nominal_cols, drop_first=True, dtype=int)
         
        education_level_mapping = {'High School': 0, 'Bachelor\'s': 1, 'Master\'s': 2, 'PhD': 3}
        df['education_level'] = df['education_level'].map(education_level_mapping)
        df['education_level'].fillna(-1, inplace=True)

        # Drop unnecessary columns
        df.drop(columns=[
            'account_id', 'customer_id', 'date_opened', 'date_closed', 'date_of_birth',
            'current_address', 'payment_history_status', 'date_last_activity', 
            'utilization_ratio'
        ], inplace=True, errors='ignore')

        df.dropna(inplace=True)
        gc.collect() 
         
        print("Data preprocessed and ready for modeling.")
        return df

    except FileNotFoundError as e:
        print(f"Error: The file was not found. Details: {e}")
        return pd.DataFrame()

# ====================================================================
# 2. EXPLORATORY DATA ANALYSIS (EDA) (Unchanged)
# ====================================================================

def eda_and_insights(df_full):
    """Performs comprehensive EDA and generates visualizations."""
    print("\n" + "="*50)
    print("--- Starting Exploratory Data Analysis (EDA) ---")
    print("="*50)
     
    # Use a sample for the pair plot for performance
    df_sample = df_full[['annual_income', 'credit_limit', 'DTI', 'age_years', 'credit_score', 'y_class_original']].sample(n=min(500, len(df_full)), random_state=42)
     
    # 1. Distribution of Target Variables
    plt.figure(figsize=(15, 6))
    plt.subplot(1, 2, 1)
    df_full['credit_score'].hist(bins=30)
    plt.title('Distribution of Credit Score (Regression Target)')
    plt.xlabel('Credit Score')
     
    plt.subplot(1, 2, 2)
    df_full['y_class_original'].value_counts().plot(kind='bar')
    plt.title('Distribution of Credit Default (Classification Target)')
    plt.xticks(ticks=[0, 1], labels=['No Default', 'Default'], rotation=0)
    plt.ylabel('Count')
    plt.tight_layout()
    plt.show()

    # 2. Correlation Heatmap
    print("\n--- Correlation Heatmap of Key Features ---")
    plt.figure(figsize=(12, 10))
    sns.heatmap(df_sample.corr(), annot=True, cmap='coolwarm', fmt=".2f")
    plt.title('Correlation Matrix of Sample Features')
    plt.show()
     
    # 3. Pair Plot (Sampled)
    print("\n--- Pair Plot (Sampled Data) ---")
    sns.pairplot(df_sample, hue='y_class_original', diag_kind='kde')
    plt.suptitle('Pair Plot of Sampled Data (Colored by Default Status)', y=1.02)
    plt.show()
     
    print("EDA Complete. Key insights are visualized.")


# ====================================================================
# 3. MODEL TRAINING, SELECTION, AND FEATURE IMPORTANCE (Fix 1: __class__.__name__)
# ====================================================================

def get_top_features(model, feature_names, n=10, task=""):
    """Extracts and prints the top N most important features."""
     
    if hasattr(model, 'feature_importances_'):
        importances = model.feature_importances_
    elif hasattr(model, 'coef_'):
        importances = np.abs(model.coef_)
        if importances.ndim > 1:
            importances = importances[0] 
    else:
        # FIX 1: Use __class__.__name__
        print(f"Cannot determine feature importance for {model.__class__.__name__}.")
        return 

    sorted_indices = np.argsort(importances)[::-1]
    top_features = feature_names[sorted_indices][:n]
     
    # FIX 1: Use __class__.__name__
    print(f"\n--- Top {n} Features for {task} ({model.__class__.__name__}) ---")
    for i, feature in enumerate(top_features):
        score = importances[sorted_indices][i]
        print(f"  {i+1}. {feature} (Score: {score:.4f})")
         
    return top_features

def train_and_evaluate_models(X_train, X_val, y_class_train, y_class_val, y_reg_train, y_reg_val):
    """
    Trains specified models, selects the best REGRESSOR based on validation set performance.
    Returns all CLASSIFIERS for manual selection.
    """
    print("\n" + "="*70)
    print("--- Training, Selection, and Feature Importance ---")
    print("="*70)
    feature_names = X_train.columns

    # ===================================================
    # --- CLASSIFICATION (Credit Default Prediction) ---
    # ===================================================
    print("\n--- CLASSIFICATION: Applying SMOTE and Training RF, XGBoost, and Logistic Regression ---")
     
    # 1. Apply SMOTE to training data
    smote = SMOTE(random_state=42)
    X_train_res, y_class_train_res = smote.fit_resample(X_train, y_class_train)
    print(f"SMOTE applied. Training samples (Original: {len(X_train)}, Resampled: {len(X_train_res)})")

    clf_models = {
        'RandomForestClassifier': RandomForestClassifier(random_state=42, n_jobs=-1),
        'XGBClassifier': xgb.XGBClassifier(random_state=42, use_label_encoder=False, eval_metric='logloss', n_jobs=-1),
        'LogisticRegression': LogisticRegression(random_state=42, solver='liblinear')
    }
     
    best_accuracy = -np.inf
    best_classifier_auto = None
    selection_results = {}

    for name, model in clf_models.items():
        # 2. Train on Resampled Data
        model.fit(X_train_res, y_class_train_res)
        y_val_pred = model.predict(X_val)
         
        # 3. Calculate Metrics (on original, non-resampled Validation Data)
        val_accuracy = (y_val_pred == y_class_val).mean()
         
        print(f"\n[MODEL: {name}] - Validation Set Performance (Selected by Accuracy)")
        print(f"  Accuracy: {val_accuracy:.4f}")
         
        # Full Classification Report
        print(f"  Classification Report:\n{classification_report(y_class_val, y_val_pred)}")
         
        # Confusion Matrix Plot
        cm = confusion_matrix(y_class_val, y_val_pred)
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['No Default (0)', 'Default (1)'])
        disp.plot(cmap=plt.cm.Blues, values_format='d')
        plt.title(f'CM for {name} (Validation Set)')
        plt.show()

        selection_results[name] = val_accuracy
         
        if val_accuracy > best_accuracy:
            best_accuracy = val_accuracy
            best_classifier_auto = model

    print("-" * 70)
    print(f"CLF SELECTION RESULTS (Accuracy): {selection_results}")
    # FIX 1: Use __class__.__name__
    print(f"BEST CLASSIFIER (Auto Selection): {best_classifier_auto.__class__.__name__} with HIGHEST ACCURACY: {best_accuracy:.4f}")
    print("-" * 70)
     
    # Note: Feature importance for CLF is moved to MAIN for the explicitly selected RFC

    # ===================================================
    # --- REGRESSION (Credit Score Prediction) ---
    # ===================================================
    print("\n--- REGRESSION: Training RF Regressor, XGBoost Regressor, and Linear Regression ---")
     
    reg_models = {
        'RandomForestRegressor': RandomForestRegressor(random_state=42, n_jobs=-1),
        'XGBRegressor': xgb.XGBRegressor(random_state=42, n_jobs=-1),
        'LinearRegression': LinearRegression(n_jobs=-1)
    }
     
    best_r2_score = -np.inf
    best_regressor = None

    for name, model in reg_models.items():
        model.fit(X_train, y_reg_train)
        val_r2 = model.score(X_val, y_reg_val)
         
        print(f"  - {name} R-squared (Validation): {val_r2:.4f}")

        if val_r2 > best_r2_score:
            best_r2_score = val_r2
            best_regressor = model

    # FIX 1: Use __class__.__name__
    print(f"\nBEST REGRESSOR SELECTED: {best_regressor.__class__.__name__} with R-squared: {best_r2_score:.4f}")
    get_top_features(best_regressor, feature_names, n=10, task="Credit Score Prediction")
     
    # Return all classifiers and the best regressor
    return clf_models, best_regressor


# ====================================================================
# 4. FINAL EVALUATION (Fix 2: __class__.__name__)
# ====================================================================

def final_evaluation(X_test, y_class_test, y_reg_test, best_classifier, best_regressor):
    """
    Performs the final evaluation on the test set using the user-selected models.
    """
    print("\n" + "="*50)
    print("--- Final Evaluation on the Test Set ---")
    print("="*50)

    # Classification: Using the user-selected model (RFC)
    # FIX 2: Use __class__.__name__
    print(f"\n--- Final Evaluation of {best_classifier.__class__.__name__} (Credit Default) ---")
    y_pred_class = best_classifier.predict(X_test)
    y_pred_proba = best_classifier.predict_proba(X_test)[:, 1] # Probability of Default
     
    # FULL CLASSIFICATION REPORT ON TEST DATA
    print(f"Final Classification Report:\n{classification_report(y_class_test, y_pred_class)}")
     
    ConfusionMatrixDisplay.from_estimator(best_classifier, X_test, y_class_test, display_labels=['No Default', 'Default'], cmap=plt.cm.Blues, values_format='d')
    # FIX 2: Use __class__.__name__
    plt.title(f'Final Confusion Matrix for {best_classifier.__class__.__name__} (Test Set)')
    plt.show()

    # Regression: Using the selected Regressor
    # FIX 2: Use __class__.__name__
    print(f"\n--- Final Evaluation of {best_regressor.__class__.__name__} (Credit Score) ---")
    y_pred_reg = best_regressor.predict(X_test)
    mse = mean_squared_error(y_reg_test, y_pred_reg)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_reg_test, y_pred_reg)
    # FIX 2: Use __class__.__name__
    print(f"Final Evaluation for {best_regressor.__class__.__name__} (Test Set):")
    print(f"  - Mean Squared Error (MSE): {mse:.4f}")
    print(f"  - Root Mean Squared Error (RMSE): {rmse:.4f}")
    print(f"  - R-squared (R²): {r2:.4f}")
     
    # Feature Importance Plot for Regression
    if hasattr(best_regressor, 'feature_importances_'):
        importances = best_regressor.feature_importances_
        feature_names = X_test.columns
        sorted_indices = np.argsort(importances)[::-1]
         
        plt.figure(figsize=(12, 8))
        # FIX 2: Use __class__.__name__
        plt.title(f"Feature Importance - {best_regressor.__class__.__name__} (Credit Score)")
        sns.barplot(x=importances[sorted_indices][:15], y=feature_names[sorted_indices][:15])
        plt.xlabel('Feature Importance')
        plt.ylabel('Feature')
        plt.tight_layout()
        plt.show()
         
    return y_pred_proba, y_class_test

# ====================================================================
# 5. BUSINESS KPI CALCULATION (Unchanged)
# ====================================================================

def calculate_business_kpis(df_test, y_pred_proba, y_class_test):
    """Calculates key business metrics based on the model's performance."""
    print("\n" + "="*50)
    print("--- BUSINESS KEY PERFORMANCE INDICATORS (KPIs) ---")
    print("="*50)

    # --- Assumptions (Adjust based on real business data/policy) ---
    LOAN_AMOUNT = 10000        
    INTEREST_RATE = 0.15       
    COST_OF_DEFAULT = LOAN_AMOUNT * (1 + INTEREST_RATE) 
    REVENUE_PER_APPROVED_LOAN = LOAN_AMOUNT * INTEREST_RATE 
    DEFAULT_THRESHOLD = 0.15   # Reject loan if P(Default) > 0.15
     
    total_loans = len(y_class_test)
    baseline_defaults = y_class_test.sum()
    baseline_default_rate = baseline_defaults / total_loans
     
    # Model Scenario: Approve loans where P(Default) <= THRESHOLD
    df_test['y_pred_proba'] = y_pred_proba
    df_test['y_true'] = y_class_test.values
     
    approved_loans_model = df_test[df_test['y_pred_proba'] <= DEFAULT_THRESHOLD]
     
    # 1. Default Rate Reduction
    if approved_loans_model.empty:
        new_model_default_rate = 0.0
    else:
        new_model_defaults = approved_loans_model['y_true'].sum()
        new_model_default_rate = new_model_defaults / len(approved_loans_model)

    reduction_percentage = 1 - (new_model_default_rate / baseline_default_rate) if baseline_default_rate else 0
     
    print(f"1. Default Rate Reduction")
    print(f"    a. Baseline Default Rate (All Loans): {baseline_default_rate:.4f}")
    print(f"    b. New Model's Default Rate (on Approved Loans): {new_model_default_rate:.4f}")
    print(f"    c. Reduction Percentage: {reduction_percentage * 100:.2f}%")
     
    # 2. Loan Approval Rate
    loan_approval_rate = len(approved_loans_model) / total_loans
    print(f"\n2. Loan Approval Rate: {loan_approval_rate * 100:.2f}%")
     
    # 3. Estimated Profit Lift
    baseline_profit = (total_loans - baseline_defaults) * REVENUE_PER_APPROVED_LOAN - \
                      (baseline_defaults * COST_OF_DEFAULT)
                       
    model_successful_loans = len(approved_loans_model) - new_model_defaults
    model_profit = (model_successful_loans * REVENUE_PER_APPROVED_LOAN) - \
                   (new_model_defaults * COST_OF_DEFAULT)
                       
    profit_lift = model_profit - baseline_profit
     
    print(f"\n3. Estimated Profit Lift (Test Set)")
    print(f"    a. Est. Profit for New Model: ${model_profit:,.2f}")
    print(f"    b. Est. Profit Baseline (Approve All): ${baseline_profit:,.2f}")
    print(f"    c. Profit Lift (New vs Baseline): ${profit_lift:,.2f}")
     
    # 4. Estimate Losses Avoided
    rejected_loans_model = df_test[df_test['y_pred_proba'] > DEFAULT_THRESHOLD]
    defaults_in_rejected_pool = rejected_loans_model['y_true'].sum()
     
    losses_avoided = defaults_in_rejected_pool * COST_OF_DEFAULT
     
    print(f"\n4. Estimated Losses Avoided (by rejecting high-risk loans): ${losses_avoided:,.2f}")

# ====================================================================
# 6. MAIN EXECUTION (Fix 3: Final Classifier print statement)
# ====================================================================

def main():
    """Main function to run the optimized pipeline."""
    # !!! CHANGE THIS TO YOUR ACTUAL FILE PATH !!!
    # FIX 3: Placeholder path correction (assuming the user intends to fix the path eventually)
    # The original path was likely not found, but the fix is the attribute error.
    # The user should ensure this path is correct.
    file_path = "main_dataset.csv" # Adjusted to a relative/placeholder path for demonstration
     
    df_processed = load_and_preprocess_data(file_path)
    if df_processed.empty:
        return

    # EDA and Insights (Use a copy to prevent accidental modifications)
    eda_and_insights(df_processed.copy())

    # Define features and targets
    X = df_processed.drop(columns=['credit_score', 'y_class_original', 'payment_was_late'], errors='ignore')
    y_reg = df_processed['credit_score']
    y_class = df_processed['payment_was_late'] 
     
    # Split data (80% Train/Val, 20% Test)
    X_train_val, X_test, y_class_train_val, y_class_test = train_test_split(
        X, y_class, test_size=0.2, random_state=42, stratify=y_class
    )
    y_reg_train_val = y_reg.loc[X_train_val.index]
    y_reg_test = y_reg.loc[X_test.index]

    # Split Train/Val (75% Train, 25% Val of the 80% split)
    X_train, X_val, y_class_train, y_class_val = train_test_split(
        X_train_val, y_class_train_val, test_size=0.25, random_state=42, stratify=y_class_train_val
    )
    y_reg_train = y_reg_train_val.loc[X_train.index]
    y_reg_val = y_reg_train_val.loc[X_val.index]

    # Train and evaluate models
    clf_models, best_regressor = train_and_evaluate_models(
        X_train, X_val, y_class_train, y_class_val, y_reg_train, y_reg_val
    )

    # --- USER OVERRIDE: SELECT RandomForestClassifier for final evaluation ---
    final_classifier = clf_models['RandomForestClassifier']
    print("\n" + "#"*70)
    # FIX 3: Use __class__.__name__
    print(f"OVERRIDE: Selecting {final_classifier.__class__.__name__} for final evaluation due to higher Recall.")
    print("#"*70)
     
    # Print Feature Importance for the user-selected RFC
    get_top_features(final_classifier, X.columns, n=10, task="Credit Default Prediction (FINAL RFC)")
     # ====================================================================
    # 6.5. MODEL SERIALIZATION (CREATING THE .pkl FILES) <--- NEW CODE BLOCK
    # ====================================================================
    print("\n" + "="*70)
    print("--- 💾 SERIALIZING (PICKLING) FINAL MODELS AND FEATURES ---")
    
    # Ensure the models directory exists
    os.makedirs('models', exist_ok=True)
    
    try:
        # 1. Save the final Credit Default Model
        with open('models/credit_default_model.pkl', 'wb') as f:
            pickle.dump(final_classifier, f)
        print("✅ Saved models/credit_default_model.pkl")

        # 2. Save the final Credit Score Model
        with open('models/credit_score_model.pkl', 'wb') as f:
            pickle.dump(best_regressor, f)
        print("✅ Saved models/credit_score_model.pkl")

        # 3. Save the list of feature columns (CRITICAL for deployment)
        # This list ensures the input data in app.py is ordered correctly.
        with open('models/feature_columns.pkl', 'wb') as f:
            pickle.dump(X.columns.tolist(), f)
        print("✅ Saved models/feature_columns.pkl")
        
    except Exception as e:
        print(f"\n🚨 ERROR saving models: {e}. Check directory permissions.")
        return # Stop execution if models cannot be saved

    print("--- Serialization Complete ---")
    print("="*70)

    # Final evaluation on the test set
    y_pred_proba, y_class_test_final = final_evaluation(
        X_test.copy(), y_class_test, y_reg_test, final_classifier, best_regressor
    )
     
    # Business KPI Calculation
    calculate_business_kpis(X_test.copy(), y_pred_proba, y_class_test_final)

    # ====================================================================
    # 7. LIME INTERPRETABILITY
    # ====================================================================
    print("\n" + "="*70)
    print("--- LIME: Local Interpretable Model Explanations ---")
    print("="*70)

    # Define the Explainer instance once using the Training Data
    # Note: Categorical features is a list of feature indices corresponding to categorical columns.
    # Here, we approximate by marking all one-hot encoded features as categorical.
    # For production use, this list should be manually verified.
    explainer = LimeTabularExplainer(
        training_data=X_train.values,
        feature_names=X_train.columns.tolist(),
        class_names=['No Default (0)', 'Default (1)'],
        mode='classification', # Default mode for the first explainer
        random_state=42
    )
     
    # --- CLASSIFIER (Credit Default) LIME Example ---
    print("\n--- CLASSIFIER LIME: Explaining a False Negative (Model Error/Missed Loss) ---")
     
    # Find a False Negative (Actual Default=1, Predicted No Default=0)
    y_pred_class_test = final_classifier.predict(X_test)
    fn_samples = X_test[(y_class_test == 1) & (y_pred_class_test == 0)]
     
    if not fn_samples.empty:
        fn_sample = fn_samples.iloc[0]
        print(f"Explaining instance index: {fn_sample.name}")
        exp_fn = explainer.explain_instance(
            data_row=fn_sample.values,
            predict_fn=final_classifier.predict_proba,
            num_features=8
        )
        print("LIME Explanation for False Negative (Reasons for predicting No Default/Missed Loss):")
        print(exp_fn.as_list())
        # Use exp_fn.show_in_notebook(show_table=True) in a Jupyter/Colab environment for visualization
        plt.figure(figsize=(10, 6))
        exp_fn.as_pyplot_figure()
        plt.title('LIME Explanation for a False Negative (CLF)')
        plt.show()
    else:
        print("No False Negative found in the test set to explain.")

    # --- REGRESSOR (Credit Score) LIME Example ---
    print("\n--- REGRESSOR LIME: Explaining a High-Error Prediction ---")
     
    # Calculate errors and find the highest error point
    y_pred_reg_test = best_regressor.predict(X_test)
    reg_errors = np.abs(y_reg_test.values - y_pred_reg_test)
    high_error_index = np.argmax(reg_errors)
    high_error_sample = X_test.iloc[high_error_index]
    actual_score = y_reg_test.iloc[high_error_index]
    predicted_score = y_pred_reg_test[high_error_index]
     
    # Re-initialize explainer for REGRESSION mode
    reg_explainer = LimeTabularExplainer(
        training_data=X_train.values,
        feature_names=X_train.columns.tolist(),
        class_names=['Credit Score'],
        mode='regression',
        random_state=42
    )
     
    print(f"Explaining instance index: {high_error_sample.name}")
    print(f"Actual Score: {actual_score:.0f}, Predicted Score: {predicted_score:.0f}")

    exp_reg = reg_explainer.explain_instance(
        data_row=high_error_sample.values,
        predict_fn=best_regressor.predict,
        num_features=8
    )
    print("LIME Explanation for High-Error Regression Prediction (Factors for the Predicted Score):")
    print(exp_reg.as_list())
    # Use exp_reg.show_in_notebook(show_table=True) in a Jupyter/Colab environment for visualization
    plt.figure(figsize=(10, 6))
    exp_reg.as_pyplot_figure()
    plt.title('LIME Explanation for a High-Error Score (RFR/XGBR)')
    plt.show()
     
    print("\nLIME Interpretability Complete.")
    print("="*70)



if __name__ == "__main__":
    main()