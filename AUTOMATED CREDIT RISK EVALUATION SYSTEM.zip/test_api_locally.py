import pandas as pd
import numpy as np
import pickle
import os
import json

# --- 1. DEFINE THE TEST DATA PAYLOAD ---
# This dictionary MUST contain all features that your model was trained on,
# with the EXACT same column names. This mirrors the JSON payload sent to the API.

TEST_PAYLOAD = {
  "credit_limit": 15000.0,
  "annual_income": 75000.0,
  "bureau_score_at_opening": 720.0,
  "months_since_last_delinquency": 12.0,
  "avg_credit_utilization": 0.35,
  "max_credit_utilization": 0.50,
  "num_high_utilization_accounts": 0,
  "num_delinquencies_30": 0,
  "num_delinquencies_60": 0,
  "num_delinquencies_90+": 0,
  "age_years": 35.5,
  "length_of_credit_history_years": 8.2,
  "age_of_youngest_account_days": 150,
  "num_new_accounts_6m": 1,
  "num_new_accounts_1y": 2,
  "total_monthly_debt": 2500.0,
  "DTI": 0.40,
  "is_active": 1,
  "account_diversity_score": 3,
  "employment_status_Employed": 1,
  "employment_status_Retired": 0,
  "employment_status_Self-Employed": 0,
  "employment_status_Unemployed": 0,
  "marital_status_Married": 1,
  "marital_status_Single": 0,
  "marital_status_Widowed": 0,
  "account_type_Credit Card": 1,
  "account_type_Mortgage": 0,
  "account_type_Personal Loan": 0,
  "education_level": 1.0,
  "number_of_dependents": 2,
  "time_at_current_job_months": 36,
  "time_at_current_address_months": 48,
  "bankruptcies": 0,
  "public_records": 0,
  # Note: 'credit_score' is dropped from features in main(), 
  # so it MUST NOT be included here as an input feature.
}

# --- 2. LOAD ARTIFACTS AND PREDICT ---

def run_local_test(payload):
    """Loads models and feature list, then makes a prediction using the payload."""
    model_path = 'models'
    
    # 1. Check if model files exist
    if not os.path.exists(model_path):
        print(f"Error: Model directory '{model_path}' not found.")
        print("Please run 'python train_models.py' first.")
        return

    # 2. Load the models and feature list
    try:
        with open(os.path.join(model_path, 'credit_default_model.pkl'), 'rb') as f:
            clf_model = pickle.load(f)
        with open(os.path.join(model_path, 'credit_score_model.pkl'), 'rb') as f:
            reg_model = pickle.load(f)
        with open(os.path.join(model_path, 'feature_columns.pkl'), 'rb') as f:
            feature_columns = pickle.load(f)
            
        print("✅ Models and feature list loaded successfully.")
    except Exception as e:
        print(f"❌ Error loading models/features: {e}")
        return

    # 3. Create DataFrame from payload
    # The payload is wrapped in a list to create a DataFrame with one row
    try:
        data_df = pd.DataFrame([payload])
    except Exception as e:
        print(f"❌ Error creating DataFrame from payload: {e}")
        return
        
    # 4. Reorder/Align the DataFrame columns to match the trained model's feature order
    # This step is critical for model compatibility
    try:
        X_test = data_df[feature_columns]
        print(f"✅ Input data created with {len(X_test.columns)} features and ready for prediction.")
    except KeyError as e:
        print(f"❌ Feature mismatch error: {e}")
        print("The features in the payload do not exactly match the features in 'feature_columns.pkl'.")
        return

    # 5. Generate Predictions
    try:
        default_pred = clf_model.predict(X_test)[0].item()
        score_pred = reg_model.predict(X_test)[0].item()
        
        # Format the output to match the API's JSON response
        output = {
            "credit_score_prediction": round(score_pred, 2),
            "is_defaulted_prediction": int(default_pred)
        }

        print("\n" + "="*50)
        print("--- LOCAL MODEL PREDICTION RESULTS ---")
        print("="*50)
        print(json.dumps(output, indent=4))
        print("="*50)
        print("Test complete. Results should match the API's output.")
        
    except Exception as e:
        print(f"❌ Error during prediction: {e}")


if __name__ == "__main__":
    run_local_test(TEST_PAYLOAD)