import pandas as pd
import pickle
from flask import Flask, request, jsonify

# Create a Flask app instance
app = Flask(__name__)

# Load the trained models and feature columns
try:
    with open('models/credit_default_model.pkl', 'rb') as f:
        default_model = pickle.load(f)
    with open('models/credit_score_model.pkl', 'rb') as f:
        score_model = pickle.load(f)
    with open('models/feature_columns.pkl', 'rb') as f:
        feature_columns = pickle.load(f)
    print("Models and features loaded successfully.")
except FileNotFoundError:
    print("Error: Model files not found. Have you run your training script to save them?")
    default_model = None
    score_model = None
    feature_columns = None

@app.route('/predict', methods=['POST'])
def predict():
    if default_model is None or score_model is None or feature_columns is None:
        return jsonify({"error": "Models not loaded. Please ensure training script was run successfully."}), 500
        
    try:
        data = request.get_json(force=True)
        df = pd.DataFrame([data])
        
        # Ensure the input DataFrame has the same column order as the training data
        df = df[feature_columns]

        # Make predictions
        default_prediction = default_model.predict(df)[0]
        score_prediction = score_model.predict(df)[0]
        
        # Format the response
        response = {
            'is_defaulted_prediction': int(default_prediction),
            'credit_score_prediction': float(score_prediction)
        }
        
        return jsonify(response)

    except Exception as e:
        return jsonify({"error": str(e)}), 400

# The Gunicorn web server looks for this variable to run the app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)