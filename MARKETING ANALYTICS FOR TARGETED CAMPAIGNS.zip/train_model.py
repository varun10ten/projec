import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, classification_report, accuracy_score
from sklearn.model_selection import train_test_split
import xgboost as xgb
import lightgbm as lgb
import warnings
import joblib

# Set a seed for reproducibility (for the KPI block and clustering)
np.random.seed(42)

# Suppress minor warnings for cleaner output
warnings.filterwarnings("ignore")

# --- GLOBAL HELPER FUNCTIONS ---

def sanitize_feature_names(df):
    """Replaces problematic characters in DataFrame column names for LightGBM/XGBoost."""
    new_cols = []
    for col in df.columns:
        # Replace common problematic characters with an underscore
        new_col = col.replace('[', '_').replace(']', '_').replace('<', '_').replace('=', '_').replace(':', '_').replace(',', '_')
        new_cols.append(new_col)
    df.columns = new_cols
    return df

def plot_elbow_method(data, max_k, title):
    """Calculates WCSS for various K values and plots the Elbow Method graph."""
    wcss = []
    k_range = range(1, max_k + 1)
    for i in k_range:
        kmeans = KMeans(n_clusters=i, init='k-means++', max_iter=300, n_init=10, random_state=42)
        kmeans.fit(data)
        wcss.append(kmeans.inertia_)
    
    plt.figure(figsize=(10, 6))
    plt.plot(k_range, wcss, marker='o', linestyle='--')
    plt.title(f'Elbow Method for Optimal K ({title})')
    plt.xlabel('Number of Clusters (K)')
    plt.ylabel('Within-Cluster Sum of Squares (WCSS)')
    plt.grid(True)
    plt.show()

def find_best_k_silhouette(data, max_k):
    """Calculates Silhouette Score for K=2 to max_k and returns the best K and score."""
    silhouette_scores = {}
    k_range = range(2, max_k + 1)
    
    if len(data) < max_k:
        max_k = len(data) - 1
        k_range = range(2, max_k + 1)
        if max_k < 2:
            return 1, 0.0

    for i in k_range:
        kmeans = KMeans(n_clusters=i, init='k-means++', max_iter=300, n_init=10, random_state=42)
        labels = kmeans.fit_predict(data)
        score = silhouette_score(data, labels)
        silhouette_scores[i] = score
        
    best_k = max(silhouette_scores, key=silhouette_scores.get)
    best_score = silhouette_scores[best_k]
    
    print(f"Silhouette Scores: {silhouette_scores}")
    return best_k, best_score

# --- 1. DATA INGESTION AND CLEANING ---

def load_and_clean_data(file_path):
    # ... (Implementation remains the same)
    print("--- 1. Data Ingestion and Initial Cleaning ---")
    
    # 1. Load Data
    all_sheets = pd.read_excel(file_path, sheet_name=None)
    customer_info = all_sheets['Customer_Info']
    offer = all_sheets['Offers']
    customer_behaviour = all_sheets['Customer_Events']
    
    # 2. Imputation
    meanofamount = customer_behaviour['amount'].mean()
    medianofreward = customer_behaviour['reward'].median()
    customer_behaviour['amount'].fillna(meanofamount, inplace=True)
    customer_behaviour['reward'].fillna(medianofreward, inplace=True)
    
    # 3. Type Conversion
    offer['reward'] = offer['reward'].astype('float64')
    
    # 4. Merging Datasets
    intermediate_df = pd.merge(customer_behaviour, offer, on='offer_id', how='outer')
    main_df = pd.merge(intermediate_df, customer_info, on='customer_id', how='outer')
    
    # 5. Post-Merge Cleanup and Renaming
    main_df['became_member_on'] = pd.to_datetime(main_df['became_member_on'])
    main_df = main_df.rename(columns={'time': 'days', 'reward_x': 'reward'})
    main_df = main_df.drop('reward_y', axis=1)
    
    print(f"Initial main_df shape: {main_df.shape}")
    print(f"Null values remaining: {main_df.isnull().sum().sum()}")
    return main_df

# --- 2. VISUALIZATION AND DATA PREPARATION ---

def visualize_and_prepare(df):
    # ... (Implementation remains the same, visualizations are omitted here for brevity)
    print("\n--- 2. Visualization and Data Preparation ---")
    
    # 1. Create Age Groups
    bins = [18, 25, 35, 45, 55, 65, 90]
    labels = ['18-25', '26-35', '36-45', '46-55', '56-65', '66+']
    df['age_group'] = pd.cut(df['age'], bins=bins, labels=labels, right=False, include_lowest=True)
    
    plt.style.use('seaborn-v0_8-whitegrid')
    
    # NOTE: The 5 visualization plots go here, as defined in the previous full code.

    # 3. Final Pre-Feature Engineering Drop
    df = df.drop('value', axis=1)
    
    return df

# --- 3. FEATURE ENGINEERING AND PREPROCESSING ---

def feature_engineering(main_df):
    # ... (Implementation remains the same, including print statements)
    print("\n--- 3. Feature Engineering and Preprocessing (Customer-Level) ---")
    
    max_days = main_df['days'].max()
    customer_features = pd.DataFrame({'customer_id': main_df['customer_id'].unique()}).set_index('customer_id')

    received = main_df[main_df['event'] == 'offer received']
    completed = main_df[main_df['event'] == 'offer completed']
    transaction = main_df[main_df['event'] == 'transaction']
    
    # 1. Response Rates
    received_counts = received.groupby(['customer_id', 'offer_type']).size().unstack(fill_value=0)
    completed_counts = completed.groupby(['customer_id', 'offer_type']).size().unstack(fill_value=0)
    viewed_info_counts = main_df[(main_df['event'] == 'offer viewed') & (main_df['offer_type'] == 'informational')].groupby('customer_id').size()

    customer_features['BOGO_Response_Rate'] = (completed_counts['BOGO'] / received_counts['BOGO']).fillna(0)
    customer_features['Discount_Response_Rate'] = (completed_counts['Discount'] / received_counts['Discount']).fillna(0)
    customer_features['Informational_View_Rate'] = (viewed_info_counts / received_counts['Informational']).fillna(0)
    
    print("\n[Output 1: Offer Response Rates (First 5 Rows)]")
    print(customer_features[['BOGO_Response_Rate', 'Discount_Response_Rate', 'Informational_View_Rate']].head())
    
    # 2. Transaction Metrics
    transaction_data = transaction.groupby('customer_id')
    customer_features['Lifetime_AOV'] = transaction_data['amount'].mean().fillna(0)
    customer_features['Total_Transactions'] = transaction_data['event'].count().fillna(0).astype(int)
    
    print("\n[Output 2: Transaction Metrics (First 5 Rows)]")
    print(customer_features[['Lifetime_AOV', 'Total_Transactions']].head())
    
    # 3. Recency
    last_activity_day = main_df[main_df['event'].isin(['transaction', 'offer completed', 'offer viewed', 'offer received'])]
    last_activity_day = last_activity_day.groupby('customer_id')['days'].max()
    customer_features['Recency_Days'] = max_days - last_activity_day
    customer_features['Recency_Days'] = customer_features['Recency_Days'].fillna(max_days)
    
    print("\n[Output 3: Recency (First 5 Rows)]")
    print(customer_features['Recency_Days'].head())

    # 4. Completion Averages (Reward and Difficulty)
    completed_offer_data = completed.groupby('customer_id')
    customer_features['Avg_Reward_Received'] = completed_offer_data['reward'].mean().fillna(0)
    customer_features['Required_Difficulty_Avg'] = completed_offer_data['difficulty'].mean().fillna(0)
    
    print("\n[Output 4: Completion Averages (First 5 Rows)]")
    print(customer_features[['Avg_Reward_Received', 'Required_Difficulty_Avg']].head())

    # 5. Average Completion Lag
    received_days = received[['customer_id', 'offer_id', 'days']].rename(columns={'days': 'received_days'})
    completed_days = completed[['customer_id', 'offer_id', 'days']].rename(columns={'days': 'completed_days'})
    lag_df = pd.merge(completed_days, received_days, on=['customer_id', 'offer_id'], how='left')
    lag_df['completion_lag'] = lag_df['completed_days'] - lag_df['received_days']
    avg_lag = lag_df.groupby('customer_id')['completion_lag'].mean()
    customer_features['Avg_Completion_Lag'] = avg_lag.fillna(0)
    
    print("\n[Output 5: Average Completion Lag (First 5 Rows)]")
    print(customer_features['Avg_Completion_Lag'].head())

    # 6. Income Buckets
    customer_demo_income = main_df[['customer_id', 'income']].drop_duplicates().set_index('customer_id')
    customer_features = customer_features.merge(customer_demo_income, left_index=True, right_index=True, how='left')
    
    income_bins = [0, 50000, 80000, 120000, np.inf]
    income_labels = ['Low', 'Medium', 'High', 'Very High']
    customer_features['Income_Bucket'] = pd.cut(customer_features['income'], bins=income_bins, labels=income_labels, right=False, include_lowest=True)
    customer_features['Income_Bucket'] = customer_features['Income_Bucket'].cat.add_categories('Unknown').fillna('Unknown')
    
    print("\n[Output 6: Income Bucket Distribution (Value Counts)]")
    print(customer_features['Income_Bucket'].value_counts())
    
    # Merge Features Back to main_df
    features_to_merge = customer_features.drop('income', axis=1)
    main_df = pd.merge(main_df, features_to_merge, on='customer_id', how='left')
    
    # Final Imputation and Dropping Unknowns
    rows_before = len(main_df)
    main_df = main_df[main_df['Income_Bucket'] != 'Unknown']
    rows_after = len(main_df)
    print(f"\n[Output 7: Final Data Cleanup] {rows_before - rows_after} rows dropped due to 'Unknown' income.")

    main_df['age_group'] = main_df['age_group'].cat.add_categories('Unspecified Age').fillna('Unspecified Age')
    
    cols_to_impute_zero = [
        'Informational_View_Rate', 'Lifetime_AOV', 'Total_Transactions',
        'Avg_Reward_Received', 'Required_Difficulty_Avg', 'Avg_Completion_Lag'
    ]
    for col in cols_to_impute_zero:
        main_df[col] = main_df[col].fillna(0)
        
    main_df = main_df[main_df['income'] >= 0]
    
    customer_index = main_df['customer_id'].unique()
    
    return main_df, customer_index

# --- 4. ENCODING AND MODELING PREPARATION (WITH CLUSTERING OUTPUT) ---

def final_prep_and_clustering(main_df, customer_index):
    """
    Performs one-hot encoding, feature scaling, PCA, and K-Means clustering.
    Includes plotting the Elbow Method and using Silhouette Score to find the best K.
    """
    print("\n--- 4. Final Preparation (Encoding, PCA, Clustering) ---")
    
    # 1. One-Hot Encoding
    cols_to_encode = ['offer_type', 'gender', 'event', 'channels', 'age_group', 'Income_Bucket']
    main_df_encoded = pd.get_dummies(main_df, columns=cols_to_encode, prefix=cols_to_encode, drop_first=True)
    bool_cols = main_df_encoded.select_dtypes(include='bool').columns
    main_df_encoded[bool_cols] = main_df_encoded[bool_cols].astype(int)
    
    # 2. Final DataFrame creation (master_df)
    cols_to_drop = ['customer_id', 'offer_id', 'became_member_on', 'Income_Bucket_Unknown', 'value']
    master_df = main_df_encoded.drop(
        columns=[col for col in cols_to_drop if col in main_df_encoded.columns], axis=1
    )
    master_df = master_df.drop('income', axis=1, errors='ignore')
    
    # 3. Create the Feature Set (X) for PCA
    X = master_df.select_dtypes(include=np.number).drop(columns=['discount_completed', 'bogo_completed', 'informational_completed', 'y_multi', 'Engineered_Cluster_ID', 'KMeans_Cluster_ID', 'M_Value', 'F_Count', 'R_Days', 'S_Response', 'D_Effort'], errors='ignore')
    
    X.replace([np.inf, -np.inf], np.nan, inplace=True)
    X.dropna(inplace=True)
    
    # 4. PCA and Clustering
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    N_components_aggressive = 8
    pca_aggressive = PCA(n_components=N_components_aggressive, random_state=42)
    X_pca_aggressive = pca_aggressive.fit_transform(X_scaled)
    
    df_clustered_pca_reduced = pd.DataFrame(
        data=X_pca_aggressive,
        columns=[f'PC_{i}' for i in range(1, N_components_aggressive + 1)],
        index=X.index
    )
    
    # --- CLUSTERING OUTPUT 1: PCA-Reduced Data ---
    print("\n[Clustering Output 1: PCA-Reduced Data]")
    # Plot Elbow Method for visualization
    plot_elbow_method(df_clustered_pca_reduced, max_k=10, title="PCA-Reduced Feature Space")
    
    # Find Best K using Silhouette Score
    K_best_pca, score_pca = find_best_k_silhouette(df_clustered_pca_reduced, max_k=10)
    print(f"-> Silhouette Score (for best K={K_best_pca}): {score_pca:.4f}")
    print(f"-> Best K value selected for master_df/PCA clustering: {K_best_pca}")
    
    K_optimal = K_best_pca
    kmeans_final = KMeans(n_clusters=K_optimal, random_state=42, n_init=10)
    kmeans_final.fit(df_clustered_pca_reduced)
    master_df.loc[X.index, 'KMeans_Cluster_ID'] = kmeans_final.labels_
    
    print(f"Master DataFrame shape: {master_df.shape}")
    print(f"Feature set X shape: {X.shape}")
    
    return master_df, X 

# --- 5. SEGMENTATION AND CLASSIFICATION MODELING (WITH VISUALIZATIONS) ---

def modeling_pipeline(master_df, X_full):
    """
    Performs feature engineering for segmentation, multi-class target creation,
    runs models, and generates visualizations (Pair Plot, Correlation Matrix).
    """
    print("\n--- 5. Segmentation and Multi-Class Modeling ---")

    # --- A. Engineered Segmentation Features ---
    df_segment_features = pd.DataFrame(index=X_full.index)
    
    df_segment_features['M_Value'] = X_full['Lifetime_AOV'] * X_full['Total_Transactions']
    df_segment_features['F_Count'] = X_full['Total_Transactions']
    df_segment_features['R_Days'] = X_full['Recency_Days'] 
    df_segment_features['S_Response'] = (X_full['BOGO_Response_Rate'] + X_full['Discount_Response_Rate']) / 2
    df_segment_features['D_Effort'] = X_full['Required_Difficulty_Avg']

    scaler_5 = StandardScaler()
    X_5_scaled = scaler_5.fit_transform(df_segment_features)
    df_5_scaled = pd.DataFrame(X_5_scaled, columns=df_segment_features.columns, index=df_segment_features.index)

    # --- CLUSTERING OUTPUT 2: Engineered Features ---
    print("\n[Clustering Output 2: Engineered Feature Space (MFRSD)]")
    # Plot Elbow Method for visualization
    plot_elbow_method(df_5_scaled, max_k=10, title="Engineered Feature Space (MFRSD)")
    
    # Find Best K using Silhouette Score
    K_best_eng, score_eng = find_best_k_silhouette(df_5_scaled, max_k=10)
    print(f"-> Silhouette Score (for best K={K_best_eng}): {score_eng:.4f}")
    print(f"-> Best K value selected for Engineered Features clustering: {K_best_eng}")
    
    K_optimal_engineered = K_best_eng
    kmeans_final_eng = KMeans(n_clusters=K_optimal_engineered, random_state=42, n_init=10)
    kmeans_final_eng.fit(df_5_scaled)
    df_segment_features['Engineered_Cluster_ID'] = kmeans_final_eng.labels_

    # Merge Engineered features and Cluster ID back to master_df
    master_df = master_df.join(df_segment_features, how='left')
    
    # --- VISUALIZATION OUTPUT ---
    print("\n[Visualization Output]")
    
    # 1. Pair Plot for Engineered Features
    plt.figure(figsize=(12, 12))
    sns.pairplot(df_segment_features.drop('Engineered_Cluster_ID', axis=1))
    plt.suptitle('Pair Plot of Engineered Segmentation Features (MFRSD)', y=1.02, fontsize=16)
    plt.show()
    print("-> Generated Pair Plot for MFRSD features.")

    # --- B. Multi-Class Target (Y) Creation ---
    
    master_df['discount_completed'] = (master_df['Discount_Response_Rate'] > 0).astype(int)
    master_df['bogo_completed'] = (master_df['BOGO_Response_Rate'] > 0).astype(int)
    master_df['informational_completed'] = (master_df['Informational_View_Rate'] > 0).astype(int)
    
    conditions = [
        (master_df['discount_completed'] == 1),
        (master_df['bogo_completed'] == 1),
        (master_df['informational_completed'] == 1)
    ]
    choices = [3, 2, 1] 
    master_df['y_multi'] = np.select(conditions, choices, default=0)
    
    # --- C. Final Data Preparation for Modeling ---
    X = master_df.drop(columns=['y_multi', 'KMeans_Cluster_ID', 'Engineered_Cluster_ID', 'discount_completed', 'bogo_completed', 'informational_completed'], errors='ignore')
    X = X.select_dtypes(include=np.number).dropna()
    y = master_df.loc[X.index, 'y_multi'] 
    
    X = X.loc[:, (X != X.iloc[0]).any()] 
    
    # 2. Correlation Matrix Heatmap
    plt.figure(figsize=(16, 12))
    corr_matrix = X.corr()
    sns.heatmap(corr_matrix, annot=False, cmap='coolwarm', fmt=".2f", linewidths=.5)
    plt.title('Correlation Matrix of All Final Features (X)', fontsize=18)
    plt.show()
    print("-> Generated Correlation Matrix Heatmap.")

    # CRITICAL FIX: Sanitize column names before modeling
    X = sanitize_feature_names(X)
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    # --- D. XGBoost and LightGBM Modeling ---
    le = LabelEncoder()
    le.fit(y)
    y_train_encoded = le.transform(y_train)
    y_test_encoded = le.transform(y_test)
    num_classes = len(le.classes_)

    # 1. XGBoost
    xgb_model = xgb.XGBClassifier(objective='multi:softmax', num_class=num_classes, n_estimators=200, max_depth=6, learning_rate=0.1, use_label_encoder=False, eval_metric='merror', random_state=42, n_jobs=-1)
    print("\nTraining XGBoost Classifier...")
    xgb_model.fit(X_train, y_train_encoded)
    xgb_pred_encoded = xgb_model.predict(X_test)
    xgb_pred = le.inverse_transform(xgb_pred_encoded.astype(int))
    xgb_accuracy = accuracy_score(y_test, xgb_pred)

    # 2. LightGBM
    lgbm_model = lgb.LGBMClassifier(objective='multiclass', num_class=num_classes, n_estimators=200, num_leaves=31, learning_rate=0.1, random_state=42, n_jobs=-1)
    print("Training LightGBM Classifier...")
    lgbm_model.fit(X_train, y_train_encoded)
    lgbm_pred_encoded = lgbm_model.predict(X_test)
    lgbm_pred = le.inverse_transform(lgbm_pred_encoded.astype(int))
    lgbm_accuracy = accuracy_score(y_test, lgbm_pred)

    # 3. Final Report
    target_names_map = {0: 'No Offer', 1: 'Informational', 2: 'BOGO', 3: 'Discount'}
    target_names_present = [target_names_map[c] for c in le.classes_]

    print("\n" + "="*50)
    print(f"XGBoost Classification Accuracy: {xgb_accuracy:.4f}")
    print("Classification Report (XGBoost):")
    print(classification_report(y_test, xgb_pred, labels=le.classes_, target_names=target_names_present, zero_division=0))
    
    print("\n" + "="*50)
    print(f"LightGBM Classification Accuracy: {lgbm_accuracy:.4f}")
    print("Classification Report (LightGBM):")
    print(classification_report(y_test, lgbm_pred, labels=le.classes_, target_names=target_names_present, zero_division=0))
    print("="*50)
    
    # =======================================================================
    # --- MODEL SAVING BLOCK (CRITICAL FOR DEPLOYMENT) ---
    # =======================================================================
    
    print("\n" + "="*50)
    print("--- SAVING MODEL ARTIFACTS FOR DEPLOYMENT ---")
    
    # 1. Save the final XGBoost model (Best performing model)
    xgb_model.save_model('offer_predictor_xgb.json')
    print("Saved: 'offer_predictor_xgb.json' (XGBoost Model)")
    
    # 2. Save the StandardScaler used for the 5 MFRSD features
    joblib.dump(scaler_5, 'scaler.pkl')
    print("Saved: 'scaler.pkl' (StandardScaler for MFRSD features)")
    
    # 3. Save the LabelEncoder for decoding predictions
    joblib.dump(le, 'label_encoder.pkl')
    print("Saved: 'label_encoder.pkl' (LabelEncoder for offer types)")

    # 4. Save the K-Means model used on Engineered Features (optional, but good practice)
    joblib.dump(kmeans_final_eng, 'kmeans_model.pkl')
    print("Saved: 'kmeans_model.pkl' (K-Means model for Engineered Cluster ID)")
    
    print("All necessary files are now saved to the local directory.")
    print("="*50)

# --- EXECUTION BLOCK ---

if __name__ == '__main__':
    # DEFINE YOUR FILE PATH HERE
    FILE_PATH = r"C:\Users\varun\OneDrive\Desktop\workoopolis project\starbucks project\synthetic_customer_data_90k_events_faker_only.xlsx"
    
    # 1. Ingestion and Cleaning
    main_df = load_and_clean_data(FILE_PATH)
    
    # 2. Visualization and Preparation
    main_df = visualize_and_prepare(main_df)
    
    # 3. Feature Engineering
    main_df, customer_index = feature_engineering(main_df)
    
    # 4. Final Prep and Clustering (Generates Elbow Plot, calculates Silhouette Score, and determines best K)
    master_df, X_full = final_prep_and_clustering(main_df, customer_index)
    
    # 5. Segmentation and Classification Modeling (Generates Pair Plot, Correlation Matrix, runs models)
    modeling_pipeline(master_df, X_full)

    # =======================================================================
    # --- KPI BLOCK (A/B TEST SIMULATION AND CALCULATION) ---
    # =======================================================================

    print("\n" + "="*50)
    print("--- KPI Block: Simulated A/B Test Results ---")
    print("="*50)
    
    # --- A. GENERATE DUMMY DATA SIMULATING A/B TEST RESULTS (N=2000) ---
    N = 2000
    df = pd.DataFrame({'customer_id': np.repeat([f'C_{i}' for i in range(N // 2)], 2)})
    df['Group'] = np.tile(['Targeted', 'Control'], N // 2)

    # --- KPI 1 & 2 Data Simulation ---
    # OCR: Control=10%, Targeted=12% (12% Lift)
    df['Offer_Completed'] = 0
    df.loc[df['Group'] == 'Control', 'Offer_Completed'] = np.random.binomial(1, 0.10, size=(N // 2))
    df.loc[df['Group'] == 'Targeted', 'Offer_Completed'] = np.random.binomial(1, 0.12, size=(N // 2))

    # Revenue and Reward Cost
    AVG_REVENUE = 50
    AVG_REWARD = 5
    COST_PER_OFFER = 0.50

    df['Revenue_Generated'] = df['Offer_Completed'] * np.random.normal(AVG_REVENUE, 10, N)
    df.loc[df['Revenue_Generated'] < 0, 'Revenue_Generated'] = 0
    df['Reward_Paid'] = df['Offer_Completed'] * np.random.normal(AVG_REWARD, 1, N)
    df.loc[df['Reward_Paid'] < 0, 'Reward_Paid'] = 0
    df['Cost_to_Deliver'] = COST_PER_OFFER

    # --- KPI 3 Data Simulation (Model Accuracy) ---
    offers = np.random.choice(['Discount', 'BOGO'], size=N)
    df['Actual_Completed_Offer'] = np.where(df['Offer_Completed'] == 1, offers, 'None')
    df['Predicted_Offer'] = df['Actual_Completed_Offer'].copy()

    # Introduce 5% error in predictions for the Targeted group
    targeted_idx = df[df['Group'] == 'Targeted'].index
    error_rate = 0.05
    error_count = int(len(targeted_idx) * error_rate)
    error_indices = np.random.choice(targeted_idx, error_count, replace=False)

    # Flip the prediction for the error cases to simulate model miss-classification
    for idx in error_indices:
        actual = df.loc[idx, 'Actual_Completed_Offer']
        if actual == 'Discount':
            df.loc[idx, 'Predicted_Offer'] = 'BOGO'
        elif actual == 'BOGO':
            df.loc[idx, 'Predicted_Offer'] = 'Discount'
        elif actual == 'None':
            # If the model incorrectly sends an offer when it should be 'None'
            df.loc[idx, 'Predicted_Offer'] = np.random.choice(['Discount', 'BOGO'])

    # --- KPI 4 Data Simulation (CAEC) ---
    df['Customer_Segment'] = np.random.choice(['Inactive', 'Active'], size=N, p=[0.2, 0.8])
    # 10% of completers from the Inactive segment make a subsequent transaction (Engaged)
    completers_idx = df[df['Offer_Completed'] == 1].index
    inactive_completers_targeted = df.loc[completers_idx].query("Customer_Segment == 'Inactive' and Group == 'Targeted'").index
    
    engaged_count = int(len(inactive_completers_targeted) * 0.10)
    engaged_count = min(engaged_count, len(inactive_completers_targeted)) 
    
    engaged_indices = np.random.choice(inactive_completers_targeted, engaged_count, replace=False)
    df['Subsequent_Transaction'] = 0
    df.loc[engaged_indices, 'Subsequent_Transaction'] = 1


    # --- B. KPI CALCULATION FUNCTIONS ---

    # 1. OCR Lift
    ocr_control = df[df['Group'] == 'Control']['Offer_Completed'].mean()
    ocr_targeted = df[df['Group'] == 'Targeted']['Offer_Completed'].mean()
    ocr_lift = ((ocr_targeted - ocr_control) / ocr_control) * 100

    # 2. ROR
    Total_Revenue_Targeted = df.loc[df['Group'] == 'Targeted', 'Revenue_Generated'].sum()
    Total_Revenue_Control = df.loc[df['Group'] == 'Control', 'Revenue_Generated'].sum()
    Total_Rewards_Paid_Out = df.loc[df['Group'] == 'Targeted', 'Reward_Paid'].sum()
    Incremental_Revenue = Total_Revenue_Targeted - Total_Revenue_Control
    ROR = Incremental_Revenue / Total_Rewards_Paid_Out if Total_Rewards_Paid_Out > 0 else np.nan

    # 3. Best Offer Prediction Accuracy
    df_targeted = df[df['Group'] == 'Targeted'].copy()
    df_eval = df_targeted[df_targeted['Actual_Completed_Offer'] != 'None']
    true_labels = df_eval['Actual_Completed_Offer'].replace('None', np.nan).dropna()
    pred_labels = df_eval.loc[true_labels.index, 'Predicted_Offer']
    labels = sorted(list(set(true_labels.unique()) | set(pred_labels.unique())))
    report = classification_report(true_labels, pred_labels, labels=labels, output_dict=True, zero_division=0)
    pred_accuracy_f1 = report['weighted avg']['f1-score']

    # 4. CAEC
    df_inactive_targeted = df[(df['Group'] == 'Targeted') & (df['Customer_Segment'] == 'Inactive')]
    Total_Marketing_Cost = (df_inactive_targeted['Reward_Paid'].sum() +
                            (df_inactive_targeted.shape[0] * COST_PER_OFFER))
    New_Engaged_Customers = df_inactive_targeted['Subsequent_Transaction'].sum()
    CAEC = Total_Marketing_Cost / New_Engaged_Customers if New_Engaged_Customers > 0 else np.nan

    # --- C. PRINT FORMATTED OUTPUT ---
    print("\n--- Final KPI Calculations ---")
    print(f"1. OCR Lift: {ocr_lift:.2f}%")
    print(f"2. ROR: {ROR:.2f}")
    print(f"3. Prediction Accuracy (F1-Score): {pred_accuracy_f1:.4f}")
    print(f"4. CAEC: ${CAEC:.2f}")
    print("="*50)