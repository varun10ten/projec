import pandas as pd
import numpy as np
import joblib 
import warnings
import flask
from flask import Flask, jsonify, request
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
import xgboost as xgb
import os

# Set a seed for reproducibility
np.random.seed(42)
# Suppress warnings for cleaner API output
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

app = Flask(__name__)

# --- CONFIGURATION / FILE PATHS ---
MODEL_PATH = 'offer_predictor_xgb.json'
SCALER_PATH = 'scaler.pkl'
ENCODER_PATH = 'label_encoder.pkl'
KMEANS_PATH = 'kmeans_model.pkl' # K-Means model for Engineered Cluster ID

# --- GLOBAL HELPER FUNCTIONS ---

def sanitize_feature_names(df):
    """Replaces problematic characters in DataFrame column names for XGBoost."""
    new_cols = []
    for col in df.columns:
        # Replace common problematic characters with an underscore
        new_col = col.replace('[', '_').replace(']', '_').replace('<', '_').replace('=', '_').replace(':', '_').replace(',', '_').replace('.', '_')
        new_cols.append(new_col)
    df.columns = new_cols
    return df

# --- 1. SYNTHETIC DATA GENERATOR (REPLACES FILE LOADING) ---

def generate_synthetic_data(num_customers=500, num_events=5000):
    """
    Generates synthetic data with distinct behavioral profiles to ensure
    the trained model is not biased towards a single class.
    """
    
    # Customer Info
    customer_ids = [f'C_{i:04d}' for i in range(num_customers)]
    genders = np.random.choice(['M', 'F', 'O'], num_customers, p=[0.45, 0.45, 0.1])
    ages = np.random.randint(20, 95, num_customers)
    incomes = np.random.normal(70000, 20000, num_customers)
    incomes[incomes < 30000] = 30000
    incomes = np.round(incomes, -3)
    member_days = pd.to_datetime('2017-01-01') + pd.to_timedelta(np.random.randint(0, 730, num_customers), unit='D')
    
    customer_info = pd.DataFrame({
        'customer_id': customer_ids,
        'gender': genders,
        'age': ages,
        'income': incomes,
        'became_member_on': member_days
    })
    
    # Introduce explicit customer profiles for better classification training
    profiles = np.random.choice(['Discount_Lover', 'BOGO_Enthusiast', 'Low_Engager'], 
                                num_customers, p=[0.4, 0.3, 0.3])
    customer_info['profile'] = profiles

    # Offers (Total 5 offers: 2 BOGO, 2 Discount, 1 Informational)
    offer_data = {
        'offer_id': ['O_A', 'O_B', 'O_C', 'O_D', 'O_E'],
        'offer_type': ['BOGO', 'Discount', 'Informational', 'BOGO', 'Discount'],
        'reward': [10.0, 5.0, 0.0, 5.0, 2.0],
        'difficulty': [10, 20, 0, 5, 10],
        'duration': [7, 7, 3, 5, 10],
        'channels': ['email,mobile,web', 'web,mobile', 'email,web', 'email', 'mobile,web,social']
    }
    offer = pd.DataFrame(offer_data)
    
    # Define a single, universal choices list: [O_A, O_B, O_C, O_D, O_E, nan] -> Length 6
    all_offer_ids = offer['offer_id'].tolist()
    
    # The list of choices for np.random.choice MUST have 6 elements
    choices = all_offer_ids + [np.nan]

    # Probabilities (Length 6, corresponding to [O_A (BOGO), O_B (Discount), O_C (Info), O_D (BOGO), O_E (Discount), nan])
    
    # 1. Discount Lover: Bias to Discount offers (O_B, O_E). Sums exactly to 1.0.
    p_discount_lover = [0.1, 0.3, 0.1, 0.1, 0.3, 0.1]
    
    # 2. BOGO Enthusiast: Bias to BOGO offers (O_A, O_D). Sums exactly to 1.0.
    p_bogo_enthusiast = [0.3, 0.1, 0.1, 0.3, 0.1, 0.1]
    
    # 3. Low Engager: Bias to 'No Offer' (nan). Sums exactly to 1.0.
    p_low_engager = [0.1, 0.1, 0.1, 0.1, 0.1, 0.5]

    event_list = []
    
    for _ in range(num_events):
        cust_id = np.random.choice(customer_ids)
        profile = customer_info[customer_info['customer_id'] == cust_id]['profile'].iloc[0]
        
        # Base probabilities for events
        # Sums to 1.0: 0.2 + 0.3 + 0.4 + 0.1 = 1.0
        event_probs = {'offer received': 0.2, 'offer viewed': 0.3, 'transaction': 0.4, 'offer completed': 0.1}
        
        # Adjust completion probability based on profile
        if profile == 'Discount_Lover':
            event_probs['offer completed'] = 0.2
        elif profile == 'BOGO_Enthusiast':
            event_probs['offer completed'] = 0.15
        
        # If event_probs don't sum to 1.0 due to adjustment, re-normalize
        p_event = list(event_probs.values())
        if not np.isclose(sum(p_event), 1.0):
             # This block handles minor floating point errors in event_probs, which is less likely
             p_event = np.array(p_event) / sum(p_event)
        
        event = np.random.choice(list(event_probs.keys()), p=p_event)
        
        offer_id_val = np.nan
        if event.startswith('offer'):
            
            # Determine the probability array based on profile
            if profile == 'Discount_Lover':
                p_current = p_discount_lover
            elif profile == 'BOGO_Enthusiast':
                p_current = p_bogo_enthusiast
            else: # Low Engager
                p_current = p_low_engager
            
            # CRITICAL CHECK FOR LENGTH AND SUM BEFORE CALLING NP.RANDOM.CHOICE
            # If this check fails, the console output will contain the detailed error.
            if len(choices) != len(p_current):
                raise ValueError(f"CRITICAL ERROR: Length mismatch in profile {profile}. Choices length: {len(choices)}, Probability length: {len(p_current)}")
            
            if not np.isclose(sum(p_current), 1.0):
                raise ValueError(f"CRITICAL ERROR: Probabilities do not sum to 1.0 in profile {profile}. Sum: {sum(p_current)}")


            offer_id_choice = np.random.choice(choices, p=p_current)
            offer_id_val = offer_id_choice if not pd.isna(offer_id_choice) else np.nan
        
        event_list.append({
            'customer_id': cust_id,
            'event': event,
            'time': np.random.randint(0, 714), # Days
            'offer_id': offer_id_val,
            'amount': np.random.normal(20, 15),
            'reward_x': np.random.normal(5, 3)
        })

    customer_behaviour = pd.DataFrame(event_list)
    customer_behaviour['amount'] = customer_behaviour['amount'].apply(lambda x: max(0, x))

    # Initial Merging & Cleanup
    intermediate_df = pd.merge(customer_behaviour, offer, on='offer_id', how='left')
    main_df = pd.merge(intermediate_df, customer_info.drop(columns=['profile']), on='customer_id', how='left') # Drop profile before returning

    main_df['amount'].fillna(main_df['amount'].mean(), inplace=True)
    main_df['reward_x'].fillna(main_df['reward_x'].median(), inplace=True)
    main_df = main_df.rename(columns={'time': 'days'})
    main_df = main_df.drop('reward_y', axis=1, errors='ignore')
    
    return main_df

# --- 2. CORE ANALYTICS FUNCTIONS ---

def visualize_and_prepare(df):
    """Prepares age groups and drops unnecessary columns."""
    bins = [18, 25, 35, 45, 55, 65, 90]
    labels_age = ['18-25', '26-35', '36-45', '46-55', '56-65', '66+'] # Renamed to avoid collision
    df['age_group'] = pd.cut(df['age'], bins=bins, labels=labels_age, right=False, include_lowest=True)
    df = df.drop('value', axis=1, errors='ignore') # 'value' column removal
    return df

def feature_engineering(main_df):
    """Generates customer-level RFM and offer response features."""
    max_days = main_df['days'].max()
    customer_features = pd.DataFrame({'customer_id': main_df['customer_id'].unique()}).set_index('customer_id')

    received = main_df[main_df['event'] == 'offer received']
    completed = main_df[main_df['event'] == 'offer completed']
    transaction = main_df[main_df['event'] == 'transaction']
    
    # 1. Response Rates
    received_counts = received.groupby(['customer_id', 'offer_type']).size().unstack(fill_value=0)
    completed_counts = completed.groupby(['customer_id', 'offer_type']).size().unstack(fill_value=0)
    
    # Ensure all offer types are present in counts (critical for consistent feature creation)
    for ot in ['BOGO', 'Discount', 'Informational']:
        if ot not in received_counts.columns: received_counts[ot] = 0
        if ot not in completed_counts.columns: completed_counts[ot] = 0

    # Calculate rates, handling NaN (from 0/0) as 0
    customer_features['BOGO_Response_Rate'] = (completed_counts['BOGO'] / received_counts['BOGO']).fillna(0)
    customer_features['Discount_Response_Rate'] = (completed_counts['Discount'] / received_counts['Discount']).fillna(0)
    
    viewed_info_counts = main_df[(main_df['event'] == 'offer viewed') & (main_df['offer_type'] == 'Informational')].groupby('customer_id').size()
    customer_features['Informational_View_Rate'] = (viewed_info_counts / received_counts['Informational']).fillna(0)
    
    # FIX: Explicitly handle infinity resulting from X/0 where X > 0.
    # Replace np.inf with 0 to prevent the 'too large for float64' error during training.
    rate_cols = ['BOGO_Response_Rate', 'Discount_Response_Rate', 'Informational_View_Rate']
    for col in rate_cols:
        customer_features[col].replace([np.inf, -np.inf], 0, inplace=True)

    # 2. Transaction Metrics
    transaction_data = transaction.groupby('customer_id')
    customer_features['Lifetime_AOV'] = transaction_data['amount'].mean().fillna(0)
    customer_features['Total_Transactions'] = transaction_data['event'].count().fillna(0).astype(int)
    
    # 3. Recency
    last_activity_day = main_df[main_df['event'].isin(['transaction', 'offer completed', 'offer viewed', 'offer received'])]
    last_activity_day = last_activity_day.groupby('customer_id')['days'].max()
    customer_features['Recency_Days'] = max_days - last_activity_day
    customer_features['Recency_Days'] = customer_features['Recency_Days'].fillna(max_days)
    
    # 4. Completion Averages
    completed_offer_data = completed.groupby('customer_id')
    customer_features['Avg_Reward_Received'] = completed_offer_data['reward_x'].mean().fillna(0)
    customer_features['Required_Difficulty_Avg'] = completed_offer_data['difficulty'].mean().fillna(0)

    # 5. Income Buckets (Needed for filtering, but features not used in final prediction)
    customer_demo_income = main_df[['customer_id', 'income']].drop_duplicates().set_index('customer_id')
    customer_features = customer_features.merge(customer_demo_income, left_index=True, right_index=True, how='left')
    
    income_bins = [0, 50000, 80000, 120000, np.inf]
    income_labels = ['Low', 'Medium', 'High', 'Very High'] # Correct label list for income
    
    # FIX: Changed 'labels' to 'income_labels'
    customer_features['Income_Bucket'] = pd.cut(customer_features['income'], bins=income_bins, labels=income_labels, right=False, include_lowest=True)
    
    customer_features['Income_Bucket'] = customer_features['Income_Bucket'].cat.add_categories('Unknown').fillna('Unknown')

    # Drop customers with unknown income/missing data before merging (as per training script)
    customer_features = customer_features[customer_features['Income_Bucket'] != 'Unknown']
    customer_features = customer_features[customer_features['income'].notna()]

    # Filter main_df to only include customers present in customer_features
    main_df = pd.merge(main_df, customer_features.reset_index()[['customer_id']], on='customer_id', how='inner')
    
    cols_to_impute_zero = [
        'Informational_View_Rate', 'Lifetime_AOV', 'Total_Transactions',
        'Avg_Reward_Received', 'Required_Difficulty_Avg'
    ]
    for col in cols_to_impute_zero:
        customer_features[col] = customer_features[col].fillna(0)

    # Only return the customer-level features used for the modeling pipeline
    return customer_features

def training_pipeline(customer_features):
    """
    Trains the final classification model and saves all artifacts.
    This function replicates the feature creation and clustering steps
    needed to train the final XGBoost model.
    """

    # 1. Isolate the 6 core customer-level features 
    customer_level_features = customer_features[['Lifetime_AOV', 'Total_Transactions', 'Recency_Days', 'BOGO_Response_Rate', 'Discount_Response_Rate', 'Required_Difficulty_Avg']].drop_duplicates().dropna()
    
    # --- A. Engineered Segmentation Features (MFRSD) ---
    df_segment_features = pd.DataFrame(index=customer_level_features.index)
    
    df_segment_features['M_Value'] = customer_level_features['Lifetime_AOV'] * customer_level_features['Total_Transactions']
    df_segment_features['F_Count'] = customer_level_features['Total_Transactions']
    df_segment_features['R_Days'] = customer_level_features['Recency_Days']  
    df_segment_features['S_Response'] = (customer_level_features['BOGO_Response_Rate'] + customer_level_features['Discount_Response_Rate']) / 2
    df_segment_features['D_Effort'] = customer_level_features['Required_Difficulty_Avg']

    scaler_5 = StandardScaler()
    X_5_scaled = scaler_5.fit_transform(df_segment_features)
    df_5_scaled = pd.DataFrame(X_5_scaled, columns=df_segment_features.columns, index=df_segment_features.index)

    # Clustering on Engineered Features (fixed at 4 clusters for API consistency)
    K_optimal_engineered = 4
    kmeans_final_eng = KMeans(n_clusters=K_optimal_engineered, random_state=42, n_init=10)
    kmeans_final_eng.fit(df_5_scaled)
    df_segment_features['Engineered_Cluster_ID'] = kmeans_final_eng.labels_

    # Merge Engineered Cluster ID back to features
    X_customer = customer_level_features.copy()
    X_customer['Engineered_Cluster_ID'] = df_segment_features['Engineered_Cluster_ID']
    X_customer.index.name = 'customer_id'
    
    # --- B. Multi-Class Target (Y) Creation (Simplification for synthetic data) ---
    
    # IMPROVED LOGIC: Prioritize BOGO/Discount response over other factors
    def get_max_offer_proxy(row):
        # 1. Discount Lover: High Discount response rate and preference
        if row['Discount_Response_Rate'] > 0.5 and row['Discount_Response_Rate'] >= row['BOGO_Response_Rate']:
            return 3  # Discount
            
        # 2. BOGO Enthusiast: High BOGO response rate and preference
        if row['BOGO_Response_Rate'] > 0.5 and row['BOGO_Response_Rate'] > row['Discount_Response_Rate']:
            return 2  # BOGO
            
        # 3. Informational: Moderate activity (Total Transactions > 5) but no strong paid offer preference
        if row['Total_Transactions'] > 5 and row['Recency_Days'] < 100:
             return 1 # Informational (Active but need a soft nudge)

        # 4. No Offer: Low activity and low response
        return 0

    y_customer = X_customer.apply(get_max_offer_proxy, axis=1)
    
    # --- C. Final Data Preparation for Modeling ---
    X = X_customer.copy()
    y = y_customer.loc[X.index]
    
    # Enforce the final 7-feature structure
    X = X[['Lifetime_AOV', 'Total_Transactions', 'Recency_Days', 'BOGO_Response_Rate', 
           'Discount_Response_Rate', 'Required_Difficulty_Avg', 'Engineered_Cluster_ID']]
    
    X = sanitize_feature_names(X)
    
    # Train/Test Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    # LabelEncoder
    le = LabelEncoder()
    le.fit(y)
    y_train_encoded = le.transform(y_train)
    num_classes = len(le.classes_)

    # XGBoost Training
    xgb_model = xgb.XGBClassifier(objective='multi:softmax', num_class=num_classes, n_estimators=100, max_depth=4, learning_rate=0.1, use_label_encoder=False, eval_metric='merror', random_state=42, n_jobs=-1)
    xgb_model.fit(X_train, y_train_encoded)
    
    # Save Artifacts for API use
    xgb_model.save_model(MODEL_PATH)
    joblib.dump(scaler_5, SCALER_PATH) # Scaler for MFRSD features
    joblib.dump(le, ENCODER_PATH)
    joblib.dump(kmeans_final_eng, KMEANS_PATH)
    
    accuracy = (xgb_model.predict(X_test) == le.transform(y_test)).mean()
    return accuracy

# --- FLASK ENDPOINTS ---

@app.route('/train', methods=['POST'])
def train_model():
    """
    Endpoint to run the full training pipeline, generate synthetic data,
    train the classification model, and save artifacts.
    NOTE: Must be run first to generate model files.
    """
    try:
        print("Starting training pipeline...")
        # Generate synthetic data
        main_df = generate_synthetic_data()
        
        # Run Pipeline Steps
        main_df = visualize_and_prepare(main_df)
        customer_features = feature_engineering(main_df)
        
        # Train and save models
        accuracy = training_pipeline(customer_features)
        
        print("Training completed. Model artifacts saved.")

        return jsonify({
            "status": "success",
            "message": "Model training complete. XGBoost model, MFRSD scaler, KMeans model, and encoder saved.",
            "final_accuracy_on_test_set": f"{accuracy:.4f}"
        }), 200

    except Exception as e:
        print(f"ERROR during training: {str(e)}")
        # This is where the custom error from generate_synthetic_data will appear in the console.
        return jsonify({
            "status": "error",
            "message": f"Training failed: {str(e)}. Check console for details."
        }), 500


@app.route('/predict', methods=['POST'])
def predict_offer_type():
    """
    Endpoint to load the saved models, take a new customer profile,
    and predict the optimal offer type (0: None, 1: Informational, 2: BOGO, 3: Discount).
    """
    # The 6 features required from the user, the 7th (Engineered_Cluster_ID) is calculated internally
    required_input_features = [
        'Lifetime_AOV', 'Total_Transactions', 'Recency_Days', 
        'BOGO_Response_Rate', 'Discount_Response_Rate', 'Required_Difficulty_Avg'
    ]
    
    try:
        data = request.get_json()
        if not all(feature in data for feature in required_input_features):
            return jsonify({
                "error": "Missing required aggregated features in request body.",
                "required_features": required_input_features
            }), 400
        
        # --- 1. Load Artifacts ---
        if not all(os.path.exists(p) for p in [MODEL_PATH, SCALER_PATH, ENCODER_PATH, KMEANS_PATH]):
             raise FileNotFoundError("One or more model artifacts are missing. Run the /train endpoint first.")

        xgb_model = xgb.XGBClassifier()
        xgb_model.load_model(MODEL_PATH)
        scaler_5 = joblib.load(SCALER_PATH)
        le = joblib.load(ENCODER_PATH)
        kmeans_model = joblib.load(KMEANS_PATH)

        # --- 2. Feature Engineering (MFRSD) for the new customer ---
        input_data = pd.DataFrame([data])
        
        # Create MFRSD features (M_Value, F_Count, R_Days, S_Response, D_Effort)
        input_data['M_Value'] = input_data['Lifetime_AOV'] * input_data['Total_Transactions']
        input_data['F_Count'] = input_data['Total_Transactions']
        input_data['R_Days'] = input_data['Recency_Days']  
        input_data['S_Response'] = (input_data['BOGO_Response_Rate'] + input_data['Discount_Response_Rate']) / 2
        input_data['D_Effort'] = input_data['Required_Difficulty_Avg']

        # Scale MFRSD features for clustering
        mfrsd_features = input_data[['M_Value', 'F_Count', 'R_Days', 'S_Response', 'D_Effort']]
        mfrsd_scaled = scaler_5.transform(mfrsd_features)
        
        # Get Engineered Cluster ID
        cluster_id = kmeans_model.predict(mfrsd_scaled)[0]
        
        # Create the final 7-feature vector matching the training set
        final_features = input_data[required_input_features].copy()
        final_features['Engineered_Cluster_ID'] = cluster_id
        
        # Apply the same column name sanitization as done during training
        final_features = sanitize_feature_names(final_features)
        
        # --- 3. Prediction ---
        xgb_pred_encoded = xgb_model.predict(final_features)
        offer_code = le.inverse_transform(xgb_pred_encoded.astype(int))[0]
        
        offer_map = {0: 'No Offer', 1: 'Informational', 2: 'BOGO', 3: 'Discount'}

        return jsonify({
            "status": "success",
            "customer_segment_id": int(cluster_id),
            "predicted_offer_code": int(offer_code),
            "predicted_offer_type": offer_map.get(int(offer_code), "Unknown")
        }), 200

    except FileNotFoundError as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 503
    except Exception as e:
        print(f"ERROR during prediction: {str(e)}")
        return jsonify({
            "status": "error",
            "message": f"Prediction failed due to internal server error: {str(e)}. Check console for details."
        }), 500

@app.route('/', methods=['GET'])
def home():
    """
    Basic endpoint to confirm the server is running.
    """
    return "Starbucks Offer Prediction Service is running! Use POST /train first, then POST /predict."


if __name__ == '__main__':
    print("---------------------------------------------------------")
    print("STARBUCKS OFFER PREDICTOR API STARTING...")
    print("1. RUN /train POST endpoint first to create model files.")
    print("2. Then run /predict POST endpoint with customer data.")
    print("---------------------------------------------------------")
    # Disabling reloader for stable running in the environment
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=False, use_reloader=False)
