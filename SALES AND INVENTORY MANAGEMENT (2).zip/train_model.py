import pandas as pd
import os
import warnings
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# --- Libraries for Model Persistence ---
import joblib 
# NOTE: Removed pickle import as all models are now saved using joblib as requested.

# --- Supervised Model Imports ---
from xgboost import XGBRegressor
from sklearn.ensemble import RandomForestRegressor

# --- Time Series Model Imports ---
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller

# --- LIME Imports for Model Interpretability ---
# NOTE: You must install LIME: pip install lime
try:
    import lime
    from lime import lime_tabular
    LIME_AVAILABLE = True
except ImportError:
    LIME_AVAILABLE = False
    print("Warning: LIME library not found. Interpretability functions will be skipped.")


# Suppress pandas and statsmodels warnings for cleaner output
warnings.filterwarnings('ignore')

# --- Configuration ---
# The hardcoded path to your Excel file
# NOTE: This path MUST be updated by the user to reflect their local environment.
EXCEL_PATH = r"C:\Users\varun\OneDrive\Desktop\workoopolis project\balaji_sales_marketing_inventory.xlsx"

# The definitive list of all sheets we are interested in
sheets={'Sales_Transactional','Sales_Geographical','Sales_Logistics','Marketing_Behavioural','Marketing_Campaign','Inventory_ProductInventory','Inventory_DailyInventory',
        'Marketing_Customer'}


# --- NEW FUNCTION FOR SAVING ALL MODELS (AS REQUESTED) ---
def save_file(xgb_model, rf_model, arima_model, sarima_model, xgb_risk_model, xgb_forecast):
    """
    Saves all six trained models using the joblib library.
    
    Note: ARIMA/SARIMA models are passed as the fitted results objects
    but are named arima_model and sarima_model internally for saving compliance.
    """
    print("\n" + "="*50)
    print("--- SAVING ALL TRAINED MODELS USING JOBLIB ---")
    print("="*50)
    
    # For the regression models
    joblib.dump(xgb_model, 'xgb_reg.pkl')
    joblib.dump(rf_model, 'rf_reg.pkl')

    # For the time-series models (Note: using the fitted results objects)
    joblib.dump(arima_model, 'arima.pkl')
    joblib.dump(sarima_model, 'sarima.pkl')

    # For the risk and forecast models
    joblib.dump(xgb_risk_model, 'xgb_risk_model.pkl')
    joblib.dump(xgb_forecast, 'xgb_forecast.pkl')

    print("All six models have been saved successfully to the current directory.")
# --- END NEW FUNCTION ---


# --- Core Functions (Data Loading, Cleaning, Feature Engineering) ---

def load_data(file_path):
    """
    Loads all sheets from the Excel file specified in EXCEL_PATH.
    Returns a dictionary of DataFrames {sheet_name: DataFrame}.
    """
    # Check if the file exists before attempting to load
    if not os.path.exists(EXCEL_PATH):
        print(f"ERROR: File not found at path: {EXCEL_PATH}")
        print("Please ensure the file path is correct.")
        return None
        
    try:
        # Load ALL sheets (sheet_name=None)
        all_sheets = pd.read_excel(EXCEL_PATH, sheet_name=None)
        print("Data loaded successfully.")
        return all_sheets
    except Exception as e:
        print(f"An error occurred during data loading: {e}")
        return None

def view_data(all_sheets):
    """
    Views the top 5 rows of specific sheets (hardcoded access).
    """
    print("\n--- Displaying Head (Top 5 Rows) of SPECIFIC Sheets ---")

    # Accessing and printing the head of each sheet as you specified
    for sheet_name in sheets:
        df = all_sheets.get(sheet_name)
        if df is not None:
            print(f"\nSHEET: {sheet_name}")
            print(df.head())
            
    return sheets

def convert_date_to_datetime(all_sheets):
    """
    Converts Unix timestamp columns to datetime objects in specific DataFrames.
    """
    print("\n--- Converting Date Columns to Datetime Objects ---")

    # Sales_Transactional
    Sales_Transactional = all_sheets.get('Sales_Transactional')
    if Sales_Transactional is not None and 'date_id' in Sales_Transactional.columns:
        # Assuming date_id is a Unix timestamp in seconds
        Sales_Transactional['date_id'] = pd.to_datetime(Sales_Transactional['date_id'], unit='s', errors='coerce')
        print("Converted 'Sales_Transactional' column 'date_id'.")
    
    # Inventory_DailyInventory
    Inventory_DailyInventory = all_sheets.get('Inventory_DailyInventory')
    if Inventory_DailyInventory is not None and 'date_id' in Inventory_DailyInventory.columns:
        # Assuming date_id is a Unix timestamp in seconds
        Inventory_DailyInventory['date_id'] = pd.to_datetime(Inventory_DailyInventory['date_id'], unit='s', errors='coerce')
        print("Converted 'Inventory_DailyInventory' column 'date_id'.")
        
    return all_sheets

def check_datatypes(all_sheets):
    """
    Prints the data types (dtypes) for all columns in all loaded DataFrames.
    """
    print("\n--- Checking Data Types (Dtypes) for All Sheets ---")
    
    for sheet_name in sheets:
        df = all_sheets.get(sheet_name)
        if df is not None:
            print(f"\n{sheet_name}:")
            print(df.dtypes)
    return all_sheets

def fill_na(all_sheets):
    """
    Fills specific missing values (NaN) in designated columns with placeholder values.
    """
    print("\n--- Applying NaN Filling (Data Cleaning) ---")
    
    # 1. Handle Inventory_ProductInventory
    Inventory_ProductInventory = all_sheets.get('Inventory_ProductInventory')
    if Inventory_ProductInventory is not None and 'flavor' in Inventory_ProductInventory.columns:
        Inventory_ProductInventory['flavor'].fillna('Unknown', inplace=True)
        print("Filled 'Inventory_ProductInventory' column 'flavor' with 'Unknown'.")
        
    # 2. Handle Marketing_Behavioural
    Marketing_Behavioural = all_sheets.get('Marketing_Behavioural')
    if Marketing_Behavioural is not None and 'purchase_id' in Marketing_Behavioural.columns:
        Marketing_Behavioural['purchase_id'].fillna('no_purchase_id', inplace=True)
        print("Filled 'Marketing_Behavioural' column 'purchase_id' with 'no_purchase_id'.")
        
    return

def check_nulls(all_sheets):
    """
    Calculates and prints the count of null (missing) values for every column 
    in the specified DataFrames.
    """
    print("\n--- Calculating Null Value Counts Per Sheet ---")
    
    for sheet_name in sheets:
        df = all_sheets.get(sheet_name)
        if df is not None:
            print(f"\nNULL COUNTS FOR SHEET: {sheet_name}")
            print(df.isnull().sum())
    return sheets

def merge_df(all_sheets):
    """
    Merges Sales_Transactional, Inventory_ProductInventory, Sales_Geographical,
    and Sales_Logistics sheets into a single master DataFrame.
    """
    print("\n--- Merging DataFrames to Create Master Sales Dataset ---")

    required_dfs = {name: all_sheets.get(name) for name in ['Sales_Transactional', 'Inventory_ProductInventory', 'Sales_Geographical', 'Sales_Logistics']}
    
    if any(df is None for df in required_dfs.values()):
        missing = [name for name, df in required_dfs.items() if df is None]
        print(f"ERROR: Cannot merge. The following sheets are missing: {', '.join(missing)}")
        return None 

    try:
        master_df = pd.merge(required_dfs['Sales_Transactional'], required_dfs['Inventory_ProductInventory'], on='product_id', how='left')
        master_df = pd.merge(master_df, required_dfs['Sales_Geographical'], on='store_id', how='left')
        master_df = pd.merge(master_df, required_dfs['Sales_Logistics'], on='order_id', how='left')
        print("All initial merges successful.")

        print(f"\nMaster DataFrame Shape: {master_df.shape}")
        print("\nMaster DataFrame Null Counts:")
        print(master_df.isnull().sum())
        
    except Exception as e:
        print(f"An error occurred during merging: {e}")
        return None

    return master_df

def feature_engineering(master_df, all_sheets):
    """
    Performs feature engineering on the master sales DataFrame.
    """
    print("\n--- Starting Feature Engineering (Time & Sales Aggregates) ---")
    
    Sales_Geographical = all_sheets.get('Sales_Geographical')
    Marketing_Behavioural = all_sheets.get('Marketing_Behavioural')
    Marketing_Customer = all_sheets.get('Marketing_Customer')
    
    if master_df is None:
        return None

    # a. Total Revenue
    master_df['total_revenue'] = master_df['quantity_sold'] * master_df['sale_price']
    
    # b. Time Features
    if 'date_id' in master_df.columns and pd.api.types.is_datetime64_any_dtype(master_df['date_id']):
        master_df['year'] = master_df['date_id'].dt.year
        master_df['month'] = master_df['date_id'].dt.month
        master_df['quarter'] = master_df['date_id'].dt.quarter
        master_df['day_of_week'] = master_df['date_id'].dt.dayofweek
        master_df['week_of_year'] = master_df['date_id'].dt.isocalendar().week.astype(int)
    
    # c. Days to Delivery
    if 'delivery_date' in master_df.columns and 'shipment_date' in master_df.columns:
        master_df['days_to_delivery'] = (master_df['delivery_date'] - master_df['shipment_date']).dt.days

    # d. Sales per Product per Store (Aggregation)
    sales_per_product_store = master_df.groupby(['product_id', 'store_id']).agg(
        total_quantity_sold_per_product_store=('quantity_sold', 'sum'),
    ).reset_index()
    master_df = pd.merge(master_df, sales_per_product_store, on=['product_id', 'store_id'], how='left')
    
    # e. Average Sale Price
    avg_sale_price_per_product = master_df.groupby('product_id')['sale_price'].mean().rename('avg_sale_price_per_product').reset_index()
    master_df = pd.merge(master_df, avg_sale_price_per_product, on='product_id', how='left')
    
    # f. Geographical Density
    if Sales_Geographical is not None:
        store_density_city = Sales_Geographical.groupby('city')['store_id'].nunique().rename('store_count_per_city').reset_index()
        master_df = pd.merge(master_df, store_density_city, on='city', how='left')

    # --- Customer Data Merge ---
    if Marketing_Behavioural is not None and Marketing_Customer is not None:
        df_purchases_behavioral = Marketing_Behavioural[Marketing_Behavioural['behavior_type'] == 'Purchase'].copy()
        transaction_to_customer_id = df_purchases_behavioral[['purchase_id', 'customer_id']].rename(columns={'purchase_id': 'transaction_id'})
        master_df = pd.merge(master_df, transaction_to_customer_id, on='transaction_id', how='left')

        master_df = pd.merge(master_df, Marketing_Customer[['customer_id', 'age', 'gender', 'income_bracket', 'psychographic_segment']], on='customer_id', how='left')

    print(f"Master DataFrame Shape after Feature Engineering: {master_df.shape}")
    return master_df

def fill_na_features(master_df, all_sheets):
    """
    Fills specific missing values (NaN) in the newly engineered/merged customer features.
    """
    if 'customer_id' in master_df.columns:
        master_df['customer_id'].fillna('Unknown ID', inplace=True)
    
    for col in ['gender', 'income_bracket', 'psychographic_segment']:
        if col in master_df.columns:
            master_df[col].fillna('Unknown', inplace=True)
            
    if 'age' in master_df.columns:
        median_age = master_df['age'].median()
        master_df['age'].fillna(median_age, inplace=True)

    return master_df

def get_latest_date(master_df):
    """
    Finds the most recent transaction date.
    """
    if master_df is None or 'date_id' not in master_df.columns:
        return None
        
    latest_date = master_df['date_id'].max()
    print(f"\n--- Latest Transaction Date Found for RFM Reference: {latest_date} ---")
    return latest_date

def calculate_rfm(master_df, latest_date):
    """
    Calculates the Recency, Frequency, and Monetary (RFM) metrics.
    """
    rfm_df = master_df[master_df['customer_id'] != 'Unknown ID'].copy()

    if rfm_df.empty:
        return pd.DataFrame(columns=['customer_id', 'recency', 'frequency', 'monetary'])

    rfm_df = rfm_df.groupby('customer_id').agg(
        recency=('date_id', lambda date: (latest_date - date.max()).days),
        frequency=('transaction_id', 'nunique'),
        monetary=('total_revenue', 'sum')
    ).reset_index()

    return rfm_df
    
def merge_rfm_df(master_df, rfm_df):
    """
    Merges RFM features back and handles nulls for unidentified customers.
    """
    master_df = pd.merge(master_df, rfm_df, on='customer_id', how='left')
    
    # Fill Recency, Frequency, and Monetary for transactions linked to 'Unknown ID'
    master_df['recency'].fillna(999, inplace=True)
    master_df['frequency'].fillna(0, inplace=True)
    master_df['monetary'].fillna(0, inplace=True)
    
    return master_df

def calculate_sales_velocity(master_df):
    """
    Calculates the Sales Velocity (Average daily quantity sold) for each product.
    """
    if master_df is None:
        return None
        
    daily_product_sales = master_df.groupby(['product_id', master_df['date_id'].dt.date])['quantity_sold'].sum().reset_index()
    daily_product_sales.rename(columns={'date_id': 'date_only', 'quantity_sold': 'daily_quantity_sold'}, inplace=True)

    sales_velocity = daily_product_sales.groupby('product_id')['daily_quantity_sold'].mean().rename('sales_velocity').reset_index()
    master_df = pd.merge(master_df, sales_velocity, on='product_id', how='left')
    
    master_df['sales_velocity'].fillna(0, inplace=True) 
    
    return master_df


def calculate_inventory_metrics(master_df, all_sheets):
    """
    Calculates Days of Inventory and Stockout Risk Score.
    """
    Inventory_DailyInventory = all_sheets.get('Inventory_DailyInventory')
    
    if master_df is None or Inventory_DailyInventory is None:
        return master_df
    
    Inventory_DailyInventory['date_only'] = Inventory_DailyInventory['date_id'].dt.date
    
    latest_daily_stock = Inventory_DailyInventory.sort_values('date_only', ascending=True).groupby(['product_id', 'date_only'])['current_stock'].last().reset_index()
    
    master_df['date_only'] = master_df['date_id'].dt.date 
    master_df = pd.merge(master_df, latest_daily_stock, on=['product_id', 'date_only'], how='left')
    
    # Calculate Days of Inventory
    master_df['days_of_inventory'] = np.where(
        (master_df['sales_velocity'] > 0) & (master_df['current_stock'].notna()),
        master_df['current_stock'] / master_df['sales_velocity'],
        np.nan 
    )
    
    # Calculate Stockout Risk Score
    master_df['stockout_risk_score'] = np.where(
        master_df['sales_velocity'] > 0,
        (1 / (master_df['current_stock'].fillna(0) + 1)) * master_df['sales_velocity'] / (master_df['shelf_life_days'].fillna(365) + 1),
        0
    )

    master_df.drop(columns=['date_only'], inplace=True) 
    
    return master_df

def customer_engagement(master_df, all_sheets):
    """
    Calculates customer engagement count from behavioral data.
    """
    Marketing_Behavioural = all_sheets.get('Marketing_Behavioural')

    if master_df is None or Marketing_Behavioural is None:
        return master_df

    customer_engagement = Marketing_Behavioural.groupby('customer_id')['interaction_id'].nunique().rename('engagement_count').reset_index()
    master_df = pd.merge(master_df, customer_engagement, on='customer_id', how='left')
    master_df['engagement_count'].fillna(0, inplace=True) 

    return master_df

def column_to_encode(master_df):
    """
    Applies Label Encoding to specified categorical columns.
    """
    categorical_cols_to_encode = [
        'gender', 'income_bracket', 'psychographic_segment', 'category',
        'sub_category', 'flavor', 'retailer_type', 'city', 'state', 'delivery_status'
    ]
    
    for col in categorical_cols_to_encode:
        if col in master_df.columns:
            if master_df[col].dtype == 'object':
                le = LabelEncoder()
                master_df[col] = le.fit_transform(master_df[col].astype(str))
            
    return master_df

def drop_unnecessary_columns(master_df):
    """
    Drops unnecessary ID, name, date, and intermediate aggregation columns.
    """
    cols_to_drop = [
        'transaction_id', 'product_id', 'store_id', 'order_id', 
        'shipment_date', 'delivery_date', 'pincode', 'date_id', 
        'customer_id', 'store_name', 
        'product_name_x', 'product_name_y', 'category_x', 'category_y',
        'total_quantity_sold_per_product_store',
        'total_revenue_per_product_store', 
        'current_stock' # Drop current_stock as it's highly correlated with the target 'stockout_risk_score' but can lead to data leakage if used directly in sales prediction.
    ]

    cols_to_drop_cleaned = [col.strip() for col in cols_to_drop]
    master_df.drop(columns=cols_to_drop_cleaned, errors='ignore', inplace=True)
    
    return master_df

def visualization(Sales_Transactional: pd.DataFrame, master_df: pd.DataFrame):
    """
    Generates time series and distribution plots for sales data.
    """
    print("\n--- Generating Data Visualizations ---")
    
    sns.set_style("whitegrid")

    # Time Series Plot of Total Daily Sales (using original sales data)
    if 'date_id' in Sales_Transactional.columns:
        df_ts = Sales_Transactional.copy()
        try:
            df_ts['date_id'] = pd.to_datetime(df_ts['date_id'])
        except Exception:
            pass

        if pd.api.types.is_datetime64_any_dtype(df_ts['date_id']):
            daily_revenue = df_ts.set_index('date_id')['sale_price'].resample('D').sum().fillna(0)
            
            plt.figure(figsize=(15, 7))
            daily_revenue.plot(title='Total Daily Revenue Over Time (from original sales data)', color='skyblue')
            plt.xlabel('Date')
            plt.ylabel('Total Sales Price')
            plt.tight_layout()
            plt.show()

    # Distribution of Quantity Sold
    if 'quantity_sold' in master_df.columns:
        plt.figure(figsize=(10, 6))
        sns.histplot(master_df['quantity_sold'], bins=30, kde=True, color='lightcoral')
        plt.title('Distribution of Quantity Sold')
        plt.xlabel('Quantity Sold')
        plt.ylabel('Frequency')
        plt.tight_layout()
        plt.show()

    # Distribution of Sale Price
    if 'sale_price' in master_df.columns:
        plt.figure(figsize=(10, 6))
        sns.histplot(master_df['sale_price'], bins=30, kde=True, color='lightgreen')
        plt.title('Distribution of Sale Price')
        plt.xlabel('Sale Price')
        plt.ylabel('Frequency')
        plt.tight_layout()
        plt.show()

# --- MODELLING AND EVALUATION ---

def modelling_and_evaluation(master_df: pd.DataFrame, Sales_Transactional: pd.DataFrame, Sales_Geographical: pd.DataFrame, Inventory_ProductInventory: pd.DataFrame):
    """
    Performs supervised regression and time series modeling, evaluates results,
    and analyzes feature importance for sales and stockout risk prediction.
    
    Returns: X_train, X_test, xgb_model, rf_model, arima_results, sarima_results, xgb_risk_model
    """
    print("\n" + "="*50)
    print("--- 6. MODEL PREPARATION AND TRAINING ---")
    print("="*50)

    # --- 6.1 Supervised Model Preparation ---
    # Define Target for Supervised Models (XGBoost, Random Forest)
    y = master_df['quantity_sold']
    X = master_df.drop(columns=['quantity_sold', 'stockout_risk_score'])
    
    # Split data for supervised models
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"\nSupervised Model Data Split: X_train shape {X_train.shape}, y_train shape {y_train.shape}")
    print(f"Supervised Model Data Split: X_test shape {X_test.shape}, y_test shape {y_test.shape}")

    # Prepare data for ARIMA/SARIMA
    # Aggregate total quantity sold by day for time series
    ts_data = Sales_Transactional.set_index('date_id')['quantity_sold'].resample('D').sum().fillna(0)
    print(f"\nTime Series Data for ARIMA/SARIMA (first 5):\n{ts_data.head()}")

    # --- 6.2 XGBoost Regressor (Predicting Quantity Sold) ---
    print("\n--- Training XGBoost Regressor (Quantity Sold) ---")
    xgb_model = XGBRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
    xgb_model.fit(X_train, y_train)
    y_pred_xgb = xgb_model.predict(X_test)
    rmse_xgb = np.sqrt(mean_squared_error(y_test, y_pred_xgb))
    r2_xgb = r2_score(y_test, y_pred_xgb)
    print(f"XGBoost RMSE: {rmse_xgb:.4f}")
    print(f"XGBoost R-squared: {r2_xgb:.4f}")
    # save_persisted_model(xgb_model, 'xgb_quantity_sold_model.pkl') # REMOVED: Saving handled by save_file

    # --- 6.3 Random Forest Regressor (Predicting Quantity Sold) ---
    print("\n--- Training Random Forest Regressor (Quantity Sold) ---")
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    rf_model.fit(X_train, y_train)
    y_pred_rf = rf_model.predict(X_test)
    rmse_rf = np.sqrt(mean_squared_error(y_test, y_pred_rf))
    r2_rf = r2_score(y_test, y_pred_rf)
    print(f"Random Forest RMSE: {rmse_rf:.4f}")
    print(f"Random Forest R-squared: {r2_rf:.4f}")
    # save_persisted_model(rf_model, 'rf_quantity_sold_model.pkl') # REMOVED: Saving handled by save_file

    # --- 6.4 ARIMA Model (Predicting Total Daily Sales) ---
    print("\n--- Training ARIMA Model ---")
    d = 0 # Default differencing
    arima_results = None
    try:
        # Check for stationarity using Augmented Dickey-Fuller test
        adf_test = adfuller(ts_data.dropna())
        print(f"ADF Statistic: {adf_test[0]:.2f}")
        print(f"p-value: {adf_test[1]:.2f}")
        if adf_test[1] > 0.05:
            d = 1
            print("Time series is likely non-stationary. Using 1st order differencing.")
        else:
            print("Time series is likely stationary.")
            d = 0
            
        order_arima = (5, d, 0)
        arima_model_obj = ARIMA(ts_data, order=order_arima)
        arima_results = arima_model_obj.fit()
        
        # Make a simple forecast
        forecast_steps = 7
        arima_forecast = arima_results.predict(start=len(ts_data), end=len(ts_data) + forecast_steps - 1)
        print(f"\nARIMA Forecast for next {forecast_steps} days (Sample):\n{arima_forecast.head(2).to_string()}")
        # save_persisted_model(arima_results, 'arima_results.joblib') # REMOVED: Saving handled by save_file

        plt.figure(figsize=(15, 7))
        plt.plot(ts_data.index, ts_data, label='Actual Sales')
        plt.plot(arima_forecast.index, arima_forecast, label='ARIMA Forecast', color='orange')
        plt.title('ARIMA Sales Forecast')
        plt.xlabel('Date')
        plt.ylabel('Quantity Sold')
        plt.legend()
        plt.show()

    except Exception as e:
        print(f"Error training ARIMA model: {e}. Skipping ARIMA comparison.")
        arima_results = None

    # --- 6.5 SARIMA Model (Predicting Total Daily Sales) ---
    print("\n--- Training SARIMA Model ---")
    order_sarima = (1, d, 1) # Non-seasonal (p,d,q)
    seasonal_order_sarima = (1, 1, 0, 7) # Seasonal (P,D,Q,s) - Weekly seasonality
    sarima_results = None
    try:
        sarima_model_obj = SARIMAX(ts_data, order=order_sarima, seasonal_order=seasonal_order_sarima)
        sarima_results = sarima_model_obj.fit(disp=False)

        # Make a simple forecast
        sarima_forecast = sarima_results.predict(start=len(ts_data), end=len(ts_data) + forecast_steps - 1)
        print(f"\nSARIMA Forecast for next {forecast_steps} days (Sample):\n{sarima_forecast.head(2).to_string()}")
        # save_persisted_model(sarima_results, 'sarima_results.joblib') # REMOVED: Saving handled by save_file

        plt.figure(figsize=(15, 7))
        plt.plot(ts_data.index, ts_data, label='Actual Sales')
        plt.plot(sarima_forecast.index, sarima_forecast, label='SARIMA Forecast', color='green')
        plt.title('SARIMA Sales Forecast')
        plt.xlabel('Date')
        plt.ylabel('Quantity Sold')
        plt.legend()
        plt.show()

    except Exception as e:
        print(f"Error training SARIMA model: {e}. Skipping SARIMA comparison.")
        sarima_results = None

    print("\nSupervised and Time Series models trained.")

    # --- 7. Next Steps: Analysis and Model Comparison ---
    print("\n" + "="*50)
    print("--- 7. MODEL ANALYSIS AND INSIGHTS (QUANTITY SOLD) ---")
    print("="*50)

    # a. Analyze XGBoost Feature Importance (Quantity Sold)
    print("\nAnalyzing XGBoost Feature Importance (Quantity Sold)...")
    feature_importances = pd.Series(xgb_model.feature_importances_, index=X.columns).sort_values(ascending=False)
    print("Top 5 most important features:")
    print(feature_importances.head(5).to_string())

    # b. Compare ARIMA and SARIMA models
    print("\n--- Comparing ARIMA and SARIMA Models ---")
    if arima_results is not None and sarima_results is not None:
        print(f"ARIMA Model AIC: {arima_results.aic:.2f}, BIC: {arima_results.bic:.2f}")
        print(f"SARIMA Model AIC: {sarima_results.aic:.2f}, BIC: {sarima_results.bic:.2f}")
    else:
        print("\nCannot compare models. One or both of the ARIMA/SARIMA models failed to train successfully.")

    # --- 8. Secondary Model: Predicting Stockout Risk ---
    print("\n" + "="*50)
    print("--- 8. SECONDARY MODEL: STOCKOUT RISK PREDICTION ---")
    print("="*50)
    
    # Define Target Variable: stockout_risk_score
    b = master_df['stockout_risk_score']
    # Note: Dropping the primary target 'quantity_sold' and other irrelevant columns
    a = master_df.drop(columns=['stockout_risk_score', 'quantity_sold', 'days_of_inventory']) # days_of_inventory is highly correlated with risk

    ## Split data
    a_train, a_test, b_train, b_test = train_test_split(a, b, test_size=0.2, random_state=42)
    print(f"Risk Model Data Split: a_train shape {a_train.shape}, b_train shape {b_train.shape}")

    # Train XGBoost model for risk prediction
    xgb_risk_model = XGBRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
    xgb_risk_model.fit(a_train, b_train)
    b_pred_risk = xgb_risk_model.predict(a_test)

    # Evaluate model
    rmse_risk = np.sqrt(mean_squared_error(b_test, b_pred_risk))
    r2_risk = r2_score(b_test, b_pred_risk)
    print(f"\nXGBoost Model Performance for predicting Stockout Risk:")
    print(f"RMSE: {rmse_risk:.4f}")
    print(f"R-squared: {r2_risk:.4f}")
    # save_persisted_model(xgb_risk_model, 'xgb_stockout_risk_model.pkl') # REMOVED: Saving handled by save_file

    # Analyze Feature Importance for Stockout Risk
    print("\nTop 5 Most Important Features for Predicting Stockout Risk:")
    feature_importances_risk = pd.Series(xgb_risk_model.feature_importances_, index=a.columns).sort_values(ascending=False)
    print(feature_importances_risk.head(5).to_string())
    
    # --- 9. Final Business Insight: Top Categories Per City ---
    print("\n" + "="*50)
    print("--- 9. FINAL BUSINESS INSIGHTS ---")
    print("="*50)
    
    if Sales_Transactional is not None and Sales_Geographical is not None and Inventory_ProductInventory is not None:
        # Merge sales with geographical data and product data
        sales_with_geo = pd.merge(Sales_Transactional, Sales_Geographical, on='store_id', how='left')
        other_df = pd.merge(sales_with_geo, Inventory_ProductInventory, on='product_id', how='left', suffixes=('_sales', '_product'))

        sales_by_city_category = other_df.groupby(['city', 'category_product'])['quantity_sold'].sum().reset_index()
        top_categories_per_city = sales_by_city_category.loc[sales_by_city_category.groupby('city')['quantity_sold'].idxmax()]

        print("\n--- Top-Selling Product Categories in Each City (Sample) ---")
        print(top_categories_per_city.head(5).to_string(index=False))
    else:
        print("\nCannot generate Top-Selling Categories analysis. Missing raw sheets.")
        
    print("\nScript execution and analysis complete.")
    
    # Return all trained models and required LIME data
    return X_train, X_test, xgb_model, rf_model, arima_results, sarima_results, xgb_risk_model

def implement_lime_explanation(X_train: pd.DataFrame, X_test: pd.DataFrame, model: XGBRegressor):
    """
    Implements LIME to explain a single prediction made by the XGBoost model.
    """
    if not LIME_AVAILABLE:
        print("\nLIME is not installed. Skipping local interpretability analysis.")
        return
        
    print("\n" + "="*50)
    print("--- 10. LIME EXPLANATION: WHY DID THE MODEL PREDICT THIS? ---")
    print("="*50)

    # 1. Define Explainer
    # LIME needs the training data as a numpy array
    explainer = lime_tabular.LimeTabularExplainer(
        training_data=np.array(X_train),
        feature_names=X_train.columns.tolist(),
        class_names=['Quantity Sold'], # Can be set for regression too
        mode='regression',
        verbose=False
    )
    
    # 2. Choose an instance to explain (the first instance in the test set)
    # Convert the test instance to a NumPy array for LIME
    instance_to_explain = X_test.iloc[0].values
    
    # 3. Generate Prediction
    predicted_value = model.predict(instance_to_explain.reshape(1, -1))[0]
    print(f"Explaining Prediction for Instance 0 in Test Set...")
    print(f"Model Predicted Quantity Sold: {predicted_value:.2f}")

    # 4. Generate LIME Explanation
    # The predict function must accept a 2D NumPy array
    explanation = explainer.explain_instance(
        data_row=instance_to_explain,
        predict_fn=model.predict,
        num_features=10 # Show the top 10 features contributing to the prediction
    )
    
    # 5. Display Explanation
    print("\n--- LIME Top 10 Feature Contributions ---")
    print("Features pushing the prediction UPWARDS (Positive weight) and DOWNWARDS (Negative weight):")
    
    # explanation.as_list() returns a list of tuples: (feature_rule, weight)
    explanation_list = explanation.as_list()
    
    # Print the explanation in a clean, tabular format
    print(pd.DataFrame(explanation_list, columns=['Feature Condition / Range', 'Impact Weight']).to_markdown(index=False))
    
    print("\nLIME analysis complete. These weights indicate the local influence of each feature on the specific predicted value.")

def perform_xgboost_category_forecast(Sales_Transactional: pd.DataFrame, Inventory_ProductInventory: pd.DataFrame):
    """
    Performs an XGBoost-based time series forecast of daily quantity sold per product category
    for the next 7 days, based on historical sales and time features.
    
    Returns: xgb_forecast (The trained model)
    """
    print("\n" + "="*50)
    print("--- 11. XGBOOST PRODUCT CATEGORY FORECAST ---")
    print("="*50)

    if Sales_Transactional is None or Inventory_ProductInventory is None:
        print("Error: Sales or Inventory data is missing for forecast. Skipping.")
        return None

    # --- 1. Load and Prepare the Data (using function arguments) ---
    print("Loading and preparing data...")
    # Use copies of the sheets passed to the function
    salessheet1 = Sales_Transactional.copy()
    inventorysheet7 = Inventory_ProductInventory.copy()
    
    # Ensure date column is datetime (it should be converted in step 3 of the main script)
    if 'date_id' in salessheet1.columns and not pd.api.types.is_datetime64_any_dtype(salessheet1['date_id']):
        salessheet1['date_id'] = pd.to_datetime(salessheet1['date_id'], errors='coerce')

    # Merge sales with product data to get product categories
    main_work_df = pd.merge(salessheet1, inventorysheet7[['product_id', 'category']].rename(columns={'category': 'category_product'}), on='product_id', how='left')

    # Drop rows with missing categories
    main_work_df.dropna(subset=['category_product'], inplace=True)

    # Create new time-based features
    main_work_df['day_of_week'] = main_work_df['date_id'].dt.dayofweek
    main_work_df['month'] = main_work_df['date_id'].dt.month
    main_work_df['year'] = main_work_df['date_id'].dt.year

    # --- 2. Aggregate Data for Forecasting ---
    # Group by date and category to get total daily sales per category
    daily_category_sales = main_work_df.groupby(['date_id', 'category_product']).agg(
        total_quantity_sold=('quantity_sold', 'sum'),
        total_revenue=('sale_price', 'sum'),
        day_of_week=('day_of_week', 'first'),
        month=('month', 'first'),
        year=('year', 'first')
    ).reset_index()

    # --- 3. Prepare Data for XGBoost Model ---
    print("\nPreparing data for XGBoost model...")
    # Encode the 'category' column to numerical values
    le = LabelEncoder()
    daily_category_sales['category_encoded'] = le.fit_transform(daily_category_sales['category_product'])

    # Define features (X) and target (y)
    q = daily_category_sales[['day_of_week', 'month', 'year', 'category_encoded']]
    w = daily_category_sales['total_quantity_sold']

    # Split the data
    q_train, q_test, w_train, w_test = train_test_split(q, w, test_size=0.2, random_state=42)

    # --- 4. Train the XGBoost Model ---
    print("\nTraining XGBoost Regressor...")
    xgb_forecast = XGBRegressor(n_estimators=500, learning_rate=0.05, random_state=42, n_jobs=-1)
    xgb_forecast.fit(q_train, w_train)
    # save_persisted_model(xgb_forecast, 'xgb_category_forecast_model.pkl') # REMOVED: Saving handled by save_file

    # --- 5. Generate Future Forecasts ---
    print("\nGenerating future forecasts...")
    # Create a date range for the next 7 days
    last_date = daily_category_sales['date_id'].max()
    future_dates = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=7)

    # Create a DataFrame for future predictions
    future_df = pd.DataFrame()
    future_df['date_id'] = np.repeat(future_dates, len(le.classes_))
    future_df['category_product'] = np.tile(le.classes_, len(future_dates))

    # Add the required features for the future dates
    future_df['day_of_week'] = future_df['date_id'].dt.dayofweek
    future_df['month'] = future_df['date_id'].dt.month
    future_df['year'] = future_df['date_id'].dt.year

    # Encode the categories for the future data
    future_df['category_encoded'] = le.transform(future_df['category_product'])

    # Make predictions
    future_q = future_df[['day_of_week', 'month', 'year', 'category_encoded']]
    future_df['forecasted_quantity'] = xgb_forecast.predict(future_q)

    # Ensure no negative predictions
    future_df['forecasted_quantity'] = future_df['forecasted_quantity'].apply(lambda x: max(0, x))

    # --- 6. Visualize the Results ---
    print("\nCreating visualizations...")
    # Get the top N categories for a cleaner plot
    top_categories = main_work_df['category_product'].value_counts().nlargest(5).index

    plt.style.use('seaborn-v0_8-whitegrid')
    fig, axes = plt.subplots(len(top_categories), 1, figsize=(15, 6 * len(top_categories)))
    fig.tight_layout(pad=5.0)
    
    # Handle the case where only one subplot is generated
    if len(top_categories) == 1:
        axes = [axes]

    for i, category in enumerate(top_categories):
        ax = axes[i]
        
        # Filter historical data for the current category
        hist_data = daily_category_sales[daily_category_sales['category_product'] == category].set_index('date_id').sort_index()
        
        # Filter forecasted data for the current category
        forecast_data = future_df[future_df['category_product'] == category].set_index('date_id')
        
        # Plot historical data
        ax.plot(hist_data.index, hist_data['total_quantity_sold'], label='Historical Sales', color='royalblue')
        
        # Plot forecasted data
        ax.plot(forecast_data.index, forecast_data['forecasted_quantity'], label='Forecasted Sales', color='darkorange', linestyle='--', marker='o')
        
        ax.set_title(f'Historical and Forecasted Sales for {category}')
        ax.set_xlabel('Date')
        ax.set_ylabel('Total Quantity Sold')
        ax.tick_params(axis='x', rotation=45)
        ax.legend()

    plt.show()

    print("\nScript execution complete. All visualizations have been displayed.")
    
    return xgb_forecast


# --- Execution ---

if __name__ == "__main__":
    # 1. Load the data
    loaded_data = load_data(EXCEL_PATH)

    if loaded_data is not None:
        # Data preparation steps (2 through 16) remain the same
        view_data(loaded_data) 
        loaded_data = convert_date_to_datetime(loaded_data)
        check_datatypes(loaded_data)
        check_nulls(loaded_data)
        fill_na(loaded_data)
        master_df = merge_df(loaded_data)
        
        if master_df is not None:
            master_df = feature_engineering(master_df, loaded_data)
            master_df = fill_na_features(master_df, loaded_data)
            master_df = customer_engagement(master_df, loaded_data)
            latest_transaction_date = get_latest_date(master_df)
            if latest_transaction_date is not None:
                rfm_df = calculate_rfm(master_df, latest_transaction_date)
                master_df = merge_rfm_df(master_df, rfm_df)

            master_df = calculate_sales_velocity(master_df)
            master_df = calculate_inventory_metrics(master_df, loaded_data)
            master_df = column_to_encode(master_df)
            master_df = drop_unnecessary_columns(master_df)
            
            Sales_Transactional = loaded_data.get('Sales_Transactional')

            # 18. Run Modelling and Evaluation (Supervised/Time Series)
            # Capture all trained models returned by the function
            X_train, X_test, xgb_model, rf_model, arima_results, sarima_results, xgb_risk_model = modelling_and_evaluation(
                master_df, 
                loaded_data.get('Sales_Transactional'),
                loaded_data.get('Sales_Geographical'),
                loaded_data.get('Inventory_ProductInventory')
            )
            
            # 19. Run LIME Explanation on the trained XGBoost model
            if xgb_model is not None:
                implement_lime_explanation(X_train, X_test, xgb_model)
            else:
                print("LIME skipped: XGBoost model could not be trained.")

            # 20. Run Specific Product Category Forecast
            xgb_forecast = perform_xgboost_category_forecast(
                loaded_data.get('Sales_Transactional'),
                loaded_data.get('Inventory_ProductInventory')
            )
            
            # 21. CALL THE NEW SAVE FUNCTION (AS REQUESTED)
            # Note: We map the results objects (arima_results, sarima_results) to the requested variable names (arima_model, sarima_model)
            if all([xgb_model, rf_model, arima_results, sarima_results, xgb_risk_model, xgb_forecast]):
                save_file(
                    xgb_model=xgb_model, 
                    rf_model=rf_model, 
                    arima_model=arima_results, 
                    sarima_model=sarima_results, 
                    xgb_risk_model=xgb_risk_model, 
                    xgb_forecast=xgb_forecast
                )
            else:
                print("\nCannot save all models: One or more models failed to train.")
