# app.py

import sys
import os
import json
from flask import Flask, jsonify, request
import pandas as pd

# IMPORTANT: Ensure your model_persistence.py file is in the same directory.
# We import the main pipeline function from it.
try:
    from model_persistence import run_pipeline
except ImportError:
    # If model_persistence.py is not found, we cannot run the application logic.
    print("FATAL ERROR: Could not import 'run_pipeline' from 'model_persistence.py'.")
    print("Ensure model_persistence.py is present and correctly named.")
    sys.exit(1)

# --- FLASK APPLICATION SETUP ---

# Create the Flask application instance
app = Flask(__name__)

# --- API Endpoints ---

@app.route('/health', methods=['GET'])
def health_check():
    """
    A simple health check endpoint required for load balancers and monitoring 
    to confirm the server is running.
    """
    return jsonify({
        "status": "ok",
        "service": "Balaji Wafers Analytics API",
        "message": "Server is running and ready to accept requests."
    }), 200


@app.route('/run-pipeline', methods=['POST'])
def run_full_pipeline():
    """
    Endpoint to trigger the full analytical pipeline: data loading, cleaning,
    feature engineering, and model training/evaluation.

    WARNING: This process is very slow and resource-intensive, making it 
    unsuitable for a high-traffic production API. It is included here 
    only to maintain compatibility with the original script's flow.
    """
    app.logger.info("Received request to run the full analytics pipeline...")
    
    try:
        # NOTE: The run_pipeline function currently prints output to stdout.
        # In a real API, this should be modified to return structured data (e.g., JSON).
        
        # Execute the entire data and model pipeline
        run_pipeline()
        
        return jsonify({
            "status": "success",
            "message": "Pipeline execution complete. Check server logs for detailed output (visualizations, metrics, etc.).",
            "warning": "This endpoint runs model training. Use /predict for production inference."
        }), 200
        
    except Exception as e:
        app.logger.error(f"Error during pipeline execution: {e}")
        return jsonify({
            "status": "error",
            "message": "An error occurred during pipeline execution. See logs for details.",
            "detail": str(e)
        }), 500

# --- Local Execution for Testing ---

if __name__ == '__main__':
    # When running locally using 'python app.py', use the native Flask server.
    # In production on AWS/Gunicorn, this block is ignored.
    print("\n--- Starting Flask API for Local Testing ---")
    print("Access health check at http://127.0.0.1:5000/health")
    
    # Use 0.0.0.0 for compatibility in containerized environments (like Docker/ECS)
    app.run(host='0.0.0.0', port=5000, debug=True)
